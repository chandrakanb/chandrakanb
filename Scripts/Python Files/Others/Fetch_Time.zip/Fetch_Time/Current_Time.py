import datetime
from openpyxl import Workbook
 
def get_current_time():
    return datetime.datetime.now()
 
def increment_time_by_one_minute(time_obj):
    return time_obj + datetime.timedelta(minutes=1)
 
def write_to_excel(filename):
    wb = Workbook()
    sheet = wb.active
    sheet.title = "Time Sheet"
    sheet["A1"] = "Sr. No."
    sheet["B1"] = "Key Name"
    sheet["C1"] = "Value"
    current_time = get_current_time()
    current_time_str = current_time.strftime("%#I:%M")
 
    incremented_time = increment_time_by_one_minute(current_time)
    incremented_time_str = incremented_time.strftime("%#I:%M")
 
    sheet["A2"] = "1"
    sheet["B2"] = "CurrentTime"
    sheet["C2"] = current_time_str
    sheet["A3"] = "2"
    sheet["B3"] = "CurrentTime_1"
    sheet["C3"] = incremented_time_str
 
    wb.save(filename)
    print(f"Current time ({current_time_str}) and incremented time by one minute ({incremented_time_str}) have been written to {filename}")
 
if __name__ == "__main__":
    filename = "TimeSheet.xlsx"
    write_to_excel(filename)