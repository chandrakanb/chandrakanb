QPST Version 2.7
Aug 18 2015

This readme covers important information concerning QPST 2.7.

Table of Contents

1. Installation notes
2. Known issues
3. Additional software notices
4. Release notes

----------------------------------------------------------------------

1. INSTALLATION NOTES

Install by running setup.exe, NOT the msi file. Setup.exe will
resolve run-time library dependencies and then run the msi file for you.

When installing QPST, the installing user may need administration privileges.

QPST no longer installs or runs on Win95, Win98, WinNT, or Win2K.

You MUST use the QUALCOMM USB device driver or a QPST compatible
device driver on your PC if you wish to use QPST with a USB port. When
used with QPST, other drivers can cause your PC to hang when you reset
or disconnect the mobile. You will have to restart your PC to recover.
Or you may find that the phone disappears from the QPST configuration
when it resets, and not reappear until you restart QPST.

----------------------------------------------------------------------

2. KNOWN ISSUES

QPST version 2.7.410 is not compatible with QXDM. The symptom is that file-based
NV items (item number > 65535) sometimes cannot be read or appear to not be
configured. Version 2.7.410 should be replaced with version 2.7.411 if QXDM is in use.

General:

The QPST has some known problems when running on a
system that is running low on disk space.  (Less than 10 Megabytes.)
In this situation, make more disk space available before continuing to
run QPST.  Note that this limitation applies mostly to the
disk drive that contains the QPST executables and DLLs.
However, it can also be a problem when saving NV Backups and/or
Service Programming information on other drives as well.

Some SURFs and FFA mobiles support both USB and serial port connectivity.
QPST supports USB through a QUALCOMM USB device driver. You must use the
mobile's Port Mapper user interface to select either USB or a UART for
diagnostics. You can connect your PC to the mobile's serial or USB port,
but not both at the same time. Connecting QPST to more than one port of
the same mobile will cause Software Download to fail.

----------------------------------------------------------------------

3. ADDITIONAL SOFTWARE NOTICES

   Xerces:

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

----------------------------------------------------------------------

4. RELEASE NOTES

8/18/2017 QPST 2.7.470
1) Fix splashlibrary issue on x86 machine.
2) Add accumulated Data dialog in Active Phones Tab.
3) Add date in "Start Client Time" column in ActiveClients Tab.
4) Add Chip id of SDM855, SDM670 & SDC670.
5) Add gloabal protocol setting for QPSTServer.
6) Add packet aggregation.
8) Add softwareDownload and Restore default filter.
9) PDC release with  QPST.PDC.1.0-00002-GENERAL-5.
10) Fix crash issue on SoftwareDownload.
11) update polling timeout for TCP & USB.
12) Remove folder path for help document.
13) update DiagSocketLogHelper.apk

7/25/2017 QPST 2.7.469
1) Add port in QPST configuration, which has been saved in config file.
2) Add SDX20M ChipID & Update MDM9665 ChipID
3) Support ReadData64 functionality in QPST.
4) Fix PRL file missing issue.
5) Read serial number from registry. Note: You need to use 1.00.46 version of Qualcomm USB driver.
6) Copyrights changed to 2017.
7) Process Id & Start time of QPST's Client are added in Active Clients Tab in QPST Configuration.
8) Add interfaces of cefs files backup.
8) QFIL releases with QPST_QFIL.WIN.2.7-20106-GENERAL-1, QFIL version is 2.0.15

6/26/2017 QPST 2.7.468
1) Fix the QPST server shut down slowly issue.
2) Create new API for VS2015 in AtmnServer: GetAppVersionInfo, GetEnablePortState & SetEnablePortState
3) Revive DIAG_QSH_TRACE.
4) Remember option of show non QC\Diag port, non QC port is also remembered when auto addition is turned off.
5) Polilng timer value's location has changed from registry to PollingTimeout.config file.
6) Fix a service programming crash.
7) Add diagsocketloghelper.apk, please refer to user manual 80-PC738-1
8) QFIL update to 2.0.13 for:
	a) Fixed UFS provision failure on Napali
	b) Fixed device programmer is missing when QFIL generates flat build.
	
5/19/2017 QPST 2.7.467
1) Synchronization to address the GetPort issue.
2) Add option of disable sahara get msm serial on QFIL 2.0.12
3) Revert Back value of DIAG_QSH_TRACE.

5/12/2017 QPST 2.7.466
1) Get QSaharaServer.exe and fh_loader.exe back to the installer.

5/09/2017 QPST 2.7.465
1) Update chip id of SDM845.
2) Add chip id of SDM450.

4/26/2017 QPST 2.7.464
1) Change value of DIAG_QSH_TRACE.
2) Fix GetEFSSubsystem API issue.
3) Update the chip id to the latest with SDM845
4) Insert debug message to help debug GetPort issue.

4/14/2017 QPST 2.7.463
1) Add IsUSBConnected Automation API for usb connect or disconnect event.
2) Fix Downalod.exe user interface in Chinese Window 10 x64 machine.

4/6/2017 QPST 2.7.462
1) Lift the 57 character restriction and replaced it with windows MAX_PATH on EFSExplorer
2) SendCommandalways to send DIAG cmd even when phone mode show as NO PHONE
3) Fix installer crash issue

3/23/2017 QPST 2.7.461
1) Fix the hostname issue when generating debug_info.txt
2) add band 71 in RLEditor
3) Get the MemDebugApp back into the installer

3/2/2017 QPST 2.7.460
1) Add support to send diag cmd when phone is in no phone state
2) update to new build process

2/16/2017 QPST 2.7.459
1) Reorganize QPSTServer Sahara global setting menus
2) Update the device discovery mechanism to avoid reading product name of when USB driver doesn't report back valid string
3) Bug fix for SB3.0 xml parsing

2/1/2017 QPST 2.7.458
1) generate pdb file to help troubleshooting
2) update extended build ID table

1/24/2017 QPST 2.7.457
1) fix memory issue when port reuse is selected in IPServer connection

1/5/2017 QPST 2.7.456
1) solve crash triggered by delete of AtlasServerEvent member before the final handling of AtlasServerEvent(client app close time)
2) add support for QSH_TRACE to pass through QPST without dropping
3) remove debug message which can potentially cause crash
4) remove QSimManager.exe

12/20/2016 QPST 2.7.455
Release skipped

12/15/2016 QPST 2.7.454
1) Updatte the chip id to the latest with 
IPQ8074,SDA660, SDM658, SDA658, SDA630, SDM840, SDX50M, QCA6290, MSM8905
2) Add memdump location in QPSTCOnfig app
3) Fix the issue of hello response setting not saved in the setting files
4) ConfigureIpConnections api fixes
5) RLEditor changes to support LTE_M1 and LTE_NB1
6) Upgrade to new splashscreen dll Splash.WIN_MS.1.0-00006-LIB-7

11/28/2016 QPST 2.7.453
1) Bug fix on QPSTConfig crash when adding new ports

11/3/2016 QPST 2.7.452
1) Device management update to facilitate a better device discovery on USB3 hub
2) QFIL releases with QPST_QFIL.WIN.2.7-20097-GENERAL-1 , BSP.SF.1.0-00017-GENERAL-1 
3) Add latest SplashScreen related dll and support analytics write
4) Update to generate more pdb files to help debug from dump analysis
5) Software Download App changes to support backup/restore prl on multiple subs.
6) Software Download App changes skip prl in restore/backup process
7) Automation interface update to support: skip reset after restoreQCN, skip restore/backup prl in restore/backupqcn
8) Service Program App changes to support load/write prl on multiple subscribers
9) Bug fix for QPST crash when windows msg interfere with server events
10)Bug fix to enable collect crash dump file bigger than 4gb
11)Make "port trace..." option as explicit with Port tab popup menu

10/17/2016 QPST 2.7.451
1) remove the analytics write

09/25/2016 QPST 2.7.450
1) PDC changes:
	a. Support select config return subscriber not supported
	b. support list config return more than 25 configs
2) Sign QPST products executables
3) Address potential memory leak with nonehdlc mode
4) Address the crash issue caused by privilege issue when accessing the qpstserver.config file
5) Add analytics
6) Provide option to skip PRL in backup QCN
7) Service program changes to support multiple subscribers


09/09/2016 QPST 2.7.449
1) Add model id for MDM9206 
2) Restart nonhdlc protocol when usb reconnect
3) Bring back outgoing ip connection
4) Adjust spc edit size so the min. input digit can be 6

07/29/2016 QPST 2.7.448
1) Update QFIl version:
QFIL QFIL.WIN.2.7-20096-GENERAL-1
FH_Loader BSP.SF.1.0-00012-GENERAL-1
2) Add support to Emmc App to enable upload phone image to host (if flash programmer supports)
3) Update new chip id

06/30/2016 QPST 2.7.447
1) 2.7.446 was used for DEBUG release
2) Cmdline launch tcp/ip server
3) Tcp/ip server reuse COM3000x port as much as possible
4) Add logic to prevent QPST crash(steability test)
5) New Feature of RF filter in restore/backup (x)QCN file

06/09/2016 QPST 2.7.445
1) QFIL updates 
BSP.SF.1.0-00012-GENERAL-1 
QPST_QFIL.WIN.2.7-20092-GENERAL-2


04/29/2016 QPST 2.7.444
1) RLEditor change for adding new record for 3gpp generic
2) Bug fix that the xqcn file has historic data

03/10/2016 QPST 2.7.443
1) New chip id support updated to the latest in sync with the chipinfo.xls
2) QPST cleanup remove WLEditor and other PDC legacy code.
3) RLEditor update LTE band 66 and fix  GENERIC_UMTS_BAND_19_850M.
4) EFSExplorer add spc back
5) Add Sahara event to indicate dump collection finishes with errors
6) Add a global flag to disable Sahara dump auto start
7) QPST add device Sahara hello intention to PortProxy

02/01/2016 QPST 2.7.442
1) Add chip id for APQ8017, MSM8217, MSM8617, MSM8998, APQ8053
2) Add LTE band 66
3) Add launching readme.txt in help menu
4) Replace QFIL with QDART_QFIL.WIN.1.0-20060-QDART-2
5) Remove following tabs from Service Programming app:
RW, Display, Sounds, Features, Phonebook, BCSMS, MMAudio, RMNET
6) enable REPLACE_115K_BAUD_WITH_RGRY
7) update QSHrink4 db swdl support to add ralative path to metabuild file.

12/02/2015 QPST 2.7.441
1) Fix swdl restore/backup finished but progress bar not reaching 100%
2) TCP/IP sending nonHDLC switch cmd to switch to nonHDLC mode
3) Progress bar set to end if the restore/backup complete signal sent

11/09/2015 QPST 2.7.440
1) update QPSTServer to allow /regserver /unregister without launch splashscreen

11/03/2015 QPST 2.7.439
1) add splashscreen to QPSTServer

10/27/2015 QPST 2.7.438
1) bug fix for load .conf file limited a size of 1024 (update max efs read/write size back to 512.) 
2) add reset device after copying qshrink4 db for sb30 swdl
3) bug fix for pdc load sw/hw conf type based on file name
4) bug fix for server crashing due to ip setting issue
5) QFIL update to \\snowcone\builds698\PROD\QDART_QFIL.WIN.1.0-20050-QDART-12
   QSAHARA_SERVER_BIN_15.05.13.14.41.37  label on QCTP401
   FH_LOADER_BIN_15.09.28.17.28.46       label on QCTP401     

10/15/2015 QPST 2.7.437
1) QPST Chip additions for 9607 variants 
2) Revert restore QCN changes(fail in the middle of restore)
3) Fix bug for Serviceprogram app, when model id defined in extend_model_ id.xml
4) SB30+ upload EFS for Qshrink4 + Update status msg to inform user EFS copy takes time

10/1/2015 QPST 2.7.436
1) CR 915342 QPST to indicate modem when QCN Restore starts by writing into a EFS

9/22/15 QPST 2.7.435
1) Add model id for 8909

8/19/15 QPST 2.7.434
1) Fix SoftwareDownload app crashing when loading xqcn
2) Add hostname and username in sahara download log
3) Display QMI interface with user friendly name or device description(when user friendly name is empty)
4) Modify -i option in PDCCmdline.exe to support both using interface id and device user friendly name(or device description if no user friendly name)
5) Group QMI interface with parent ID and primary interface.
6) Map some known PDC QMI error code with error description
7) Bug fix in PDCCmdline.exe to fix the MBN status typo actvie->active

6/19/15 QPST 2.7.433
1) Bug fix for PDCCmdline.exe deactivate
2) Bug fix for not able to list non qualcomm pid device

6/12/15 QPST 2.7.432
1) Add support for Extended Mobile ID for Lykan 9x07.
2) Update QFIL, include FH_Loader.exe and QSaharaServer.exe


6/3/15 QPST 2.7.431
1) Bug fix - After a while phones show "N/A" status in QPST Configuration.

2) Reserve MODEL_MDM9x55 = 4114 for use in extended_model_id.xml.

3) Add support for Extended Mobile ID command version 2.

4) Standalone PDC tool

5) Add support for:
Extend model ID for the model family ver2 cmd. Add following
    <Mobile_Model_Family_Response version="2" chip_id="0x116" QPST_name="MSM8976"/>
    <Mobile_Model_Family_Response version="2" chip_id="0x10A" QPST_name="MSM8956"/>
    <Mobile_Model_Family_Response version="2" chip_id="0x115" QPST_name="APQ8076"/>
    <Mobile_Model_Family_Response version="2" chip_id="0x112" QPST_name="APQ8056"/>

6) Remove the mcfg_tab and start to use PDC standalone tool shipped with QPST.

7) QSimManager


4/9/15 QPST 2.7.430
1) Added support for non-HDLC diagnostic communication protocol, version 1. This protocol requires device support.
   It can be enabled/disabled through QPST Configuration Ports tab, using a right click menu on a COM port
   ("Configure Communication Protocol"). The new mode takes effect the next time the COM port is opened.
   The choices are:
   "HDLC Only" - this is the protcol in use by Qualcomm up to this point.
   "On initial connection switch to non-HDLC if device is compatible" - attempt to connect to device with non-HDLC
      but fall back to HDLC if this fails. Only attempts non-HDLC when COM port is opened or reopened.
   "Support non-HDLC protocol but don't initiate the mode change" - you can send the mode change command through
      QXDM (75 18 24 2 1). This selection is useful for debugging this feature.
2) Added support to identify device by using the modem family command, version 1 (75 50 06 00). See comments in
   C:\ProgramData\QUALCOMM\QPST\extended_model_id.xml for details.
3) Fix case where invalid xqcn file will lead to a crash.
4) Improve search for QMI interface for the MCFG_PDC tool.

1/14/15 QPST 2.7.429
1) Added support for "MSM8929" as model ID 4113.
2) Updated QFIL to version 2.0.03
   Changes:
   Support "flavor" and "storage" settings for download and flat Meta Build
   Support up to 200 files in rawprogram file
   Remove the 128 file limit

12/18/14 QPST 2.7.428
1) In RL Editor, add support for LTE bands 32, 125, 126, 127.
   Note that band 125-127 is encoded as 60-62 because the band field is only 6 bits long (maximum 63).
2) Fix problem where an exception or null pointer is returned from GetCOMPortList(), when a script calls
   it numerous times during an extended run.
3) Create a checkbox in the Sahara Configuration menu to enable the RAM dump timestamp feature. With this
   enabled Sahara RAM dump folder names will be in the form "Port_COM25_20141001131159557" where the
   timestamp string is yyyymmddhhmmsssss.

12/1/14 QPST 2.7.427
1) Added support for "MSM8992" as model ID 4111.
2) Added support for "MSM8996" as model ID 4112.
3) Work around problem where USB serial number string descriptor returns an invalid bDescriptorType
   value for 8994 when it's operating in Sahara mode. This appears to be a Microsoft issue with single
   instance USB devices and USB protocol version 2.1.

11/12/14 QPST 2.7.426
1) For Windows Vista and later installations, IPv6 support is now availble for incoming Diagnostic
   connections. The QPST Configuration IP Server tab now has a combo box to select IPv4 or IPv4+IPv6,
   located to the right of the "Accept client connetions" checkbox. The IPv4 selection will allow
   only IPv4 connections - this is the behavior for QPST 2.7.425 and earlier. The IPv4+IPv6 selection
   allows connections from both IPv4 and IPv6 devices. To change the state of this combo box first
   un-check "Accept client connetions", change the state of the combo box, then check the "Accept"
   checkbox. This combo box is not available for Windows XP because XP does not offer complete support
   for IPv6.

10/24/14 QPST 2.7.425
1) Updated QFIL to version 2.0.02 to support UFS flash chips.
2) Added support for "MSM8952" as model ID 4110.

9/25/14 QPST 2.7.424
1) Added support for PDC on Windows XP PCs.
2) Added support for MDM9x09 as model ID 4109
3) Updated QFIL to version 2.0.0.0 to resolve crash issue.

9/5/14 QPST 2.7.423
1) Make .xqcn default qcn format for qcnview, serviceprogramapp and also swdl app
2) Allow send DIAG cmd in QPSTConfig app(even phone is in NO PHONE state)
3) Fix software download app MCFG_PDC page bug
   - When QMI cmd(or none critical failure happened), PDC UI should not prevent workflow to continue
   - Select the right type of config(HW or SW) when activate the config
   - Refresh when multiple interfaces disconnect/reconnect
4) In software download app disable the dual device page
5) In software download app disable pdc page if OS is less than win7
6) Do not install PDC feature if OS version is less than Win7
7) Use latest GobiConnectionMgr.dll (same source used to generate Gobi Development Kit 3.0.30) to fix the random crash at PDC device disconnect
8) QFIL 2.0.0.0 (based on merge module generated from QDART_QFIL.WIN.1.0-20000-QDART-19)
9) Fix unknown reasons when built with VS2010, QCNView throw an exception if you try to convert Unix time 0 to a string and you're not in the PST zone

7/30/14 QPST 2.7.422
1) The AMPS page has been removed from Service Programming since recent chipsets do not support AMPS.
2) The Voice Recognition database backup/restore feature has been removed from Service Programming
   since that specific VR implementation is no longer supported.
3) Start menu links to the Factory Test Mode and RF NV Item Manager warning document have been removed.
4) Start menu links to DMProxyWin and DisplayCapture will now point to a warning document since
   these apps are deprecated and will be removed from the QPST\bin folder in the future.
5) Added support for MSM8909 as model ID 4108.

6/19/14 QPST 2.7.421
1) Added support for APQ8094 as model ID 4107
   Added support for MSM8936 as model ID 4106
2) Added support for LTE band 45 to RL Editor.
3) Improved Sahara mode synchronization to address these issues:
   a) The device exceeded the Hello timeout.
   b) Device transitioned into Sahara mode w/o USB disconnect/reconnect.
   c) QPST server was started with device having already sent Sahara Hello or restarted with a device already in Sahara download/memory dump.
   Changes are:
   i) Increased the Sahara Hello timeout from 150 to 300 ms.
   ii) In the "no phone" state, if the QPST server receives Sahara Hello or End Tx in response to polling it will switch to Sahara mode.
       For End Tx it will now send a Sahara Reset command (no other recovery is possible from this state).
4) Increased maximum receive size to 16k bytes.

5/21/14 QPST 2.7.420
1) Fixed additional case of "Pure virtual function call" when a device is disconnected while in Sahara mode.
2) Added support for 9x45 device as model ID 4105.

5/2/14 QPST 2.7.419
1) Fixed problem in eMMC Software Download that was causing patch0.xml expression parsing failures
   ("statement parsing error: no operator/operand found but more text in string").
2) Change NV backup so that items 880, 881, 882 are only backed up once.
3) EFS Explorer - new option to only disable mobile sleep while sending EFS commands.
   If "Always disable mobile sleep" is set, or if the device supports the WCDMA status command and
   "Disable sleep if mobile supports WCDMA status command" is set, then a new set of radio buttons
   control when sleep is disabled:

   "Disable sleep entire time this application is running"- this is the legacy behavior. Sleep is disabled
   when the application starts, and restored to its original state when the application is closed.

   "Disable sleep only when sending EFS commands"- disables sleep before sending EFS commands, then restores
   the original state after sending the commands.

   Disabling sleep when accessing EFS is recommended because during mobile sleep EFS commands may take an
   extremly long time to complete. Small file transfers can take minutes instead of seconds.
4) Removed prompt for SPC from EFS Explorer since SPC doesn't protect EFS contents.
5) Fixed problem where drag of a file from EFS Explorer to the host PC could cause a QPST server crash.
6) Fixed "Pure virtual function call" crash that could, depending on QPST Server configuration, occur after a USB disconnect.
7) QPST Server will now enable the "IP Server" function by default.

4/15/14 QPST 2.7.418
1) Updated PDC support for multiple subscribers.
2) Added support for APQ8026 as model ID 4104.

3/25/14 QPST 2.7.417
1) Adding IpConnectionStatus and ConfigureIpConnections to root automation server interface.
   ConfigureIpConnections controls the settings in QPST Configuration, IP Server tab.

   # see examples in Automation Samples on how to initialize $qpst
   # $arg1: enable ("1") or disable ("0") the IP server
   # $arg2: "" to have the server listen on INADDR_ANY (usual case), or a dotted-decimal IPv4 address of a valid network interface on this PC
   # $arg3: "" to have the Winsock library choose the TCP port number, or a decimal value (usually 2500) to specify the listen port
   # $arg4: "0" (usual case) or "1" for the upper and lower radio buttons on the IP Server tab "Create COM3000x ports..."
   # Use ConfigureIpConnections("0", "", "", "") to disable the IP server.
   # Use ConfigureIpConnections("1", "", "2500", "0") to enable the IP server with the usual default setting.
   my $retstatus = $qpst->ConfigureIpConnections($arg1, $arg2, $arg3, $arg4);
   
   # Returned string is in the form "1,,2500,0".
   # The four substrings are the same as the four arguments to ConfigureIpConnections.
   my $state = $qpst->IpConnectionStatus();

2) Added model ID support for 8939 device.
3) Added support for command 0x9B, compressed streaming data. The QPST port server will decompress the payload and expand it into
   multiple logs/events/debug messages. Client applications like QXDM will not see the 0x9B command code unless QPST can't successfully
   expand the payload.
4) FireHoseGUI.exe has been renamed QFIL.exe, and has been updated to fix bugs and support more devices.
   Users of eMMC and UFS flash chips should use QFIL instead of eMMC Software Download. All new chipsets will only be supported by QFIL.exe.
5) PDC support has been added to Software Download.
6) Added support to automation server to retrieve build image revision strings (if device supports this feature).
   The function returns comma seperated revision strings, for example:
   "00:BOOT.BF.2.1-2.1.1010DAAAANAAA:CRM,01:TZ.BF.2.2-2.2.0031DATAANAAA:CRM,03:RPM.BF.1.2-0.0.597AAAAANAAR:CRM"
   Each revision string uses the format "image index : Qualcomm version and variant : OEM version"

   # see examples in Automation Samples on how to initialize $qpst
   my $port = $qpst->GetPort($port_name);
   my $result = $port->ImageVersionReport();

3/7/14 QPST 2.7.416
1) Fix offline timeouts by adding TD state polling to mode offline logic.
2) Added model ID support for 8994 and FSMs chipsets.
3) Updated FireHoseGUI.exe with bug fixes. See (3) in QPST 2.7.413.
   Users should begin using FireHoseGUI.exe in place of eMMC Software Download if their contents.xml file
   has a <device_programmer> tag, and the tag specifies a file with "firehose" in the name, like prog_emmc_firehose_8x26.mbn.

02/03/14 QPST 2.7.415
1) Added TD-SCDMA polling command for USB/Serial devices.
2) Added SetServerDisableSaharaAutoResetFlag method to the root automation interface. This allows global disable/enable
   of auto reset after a Sahara memory dump is saved. See (3) in 2.7.414 notes.
3) eMMC Software Download, added support for storage_type in download_file, partition_file, and partition_patch_file sections.

01/17/14 QPST 2.7.414
1) A XML parser bug that would cause an occasional crash during Sahara flashless download has been fixed.
2) The "Sahara XML file" setting is now persistant across QPST sessions.
3) A new "Disable Auto Reset After Collecting Dump" setting is available in the QPST server icon right click menu.
   Setting this option will prevent QPST from sending a Sahara reset command after collecting a memory dump on
   any COM port. Some reference devices will crash during eMMC Software Download (because the apps processor
   image is missing), this option will prevent QPST from resetting the device during software download.

12/13/13 QPST 2.7.413
1) Added support for QShrink 4.0 command code 153. This command code represents a debug text message ("F3" message) containing
   a QShrink payload.
2) Fix problems in NV item restore that caused the restore of EFS files to terminate early on certain warning conditions instead
   of continuing. This would result in an incomplete restore of EFS files.
3) Introduce an initial release of software download that uses the Qualcomm Firehose download protocol (FireHoseGUI.exe). This protocol
   will be used with UFS and some eMMC flash chips. Currently the Firehose download application must have exclusive use of the COM port,
   so to use the FirehoseGui.exe application with this release of QPST you must first close QPST. Sharing of the COM port will be
   introduced in a future QPST version. Firehose download uses a new flash programmer, but the XML control files are the same
   format as eMMC Software Download. You must install the .net 4.0 runtime if it is not already present to use FireHoseGUI.exe.

11/8/13 QPST 2.7.412
1) Update 64-bit Sahara memory dump to use new format of dump command (64-bit address/data). The version of commands that
   were supported by QPST 2.7.408 has been deprecated.
2) For NV Restore of EFS file data, create regular file path if the path does not exist, when writing regular type NV file.
3) Added some new port control features required by the Firehose download protocol (80-NG319-1).

10/10/13 QPST 2.7.411
1) Resolve incompatibility issue with QXDM.
2) The port trace feature now includes a circular buffer for important events. The contents of this buffer will be printed at the
   beginning of the port trace. This helps debugging of problems that occurred before the port trace was enabled.
3) Introduce a 1 second delay if the client application tries sending a command when the device is in Sahara mode.
4) On a Sahara memory read buffer overrun (CE_RXOVER) reduce the read size to 65536 for the read retry and further reads of this memory
   segment. If the overrun persists then the user may have neglected to disable mass storage and the system is slowing going into a frozen
   state.
5) EFS Explorer file copy dialog will now (just like drag & drop) use the file system sync command after writing a file. On the device this
   will flush the RAM cache to the flash chip.
6) Roaming list editor: Add LTE bands 27, 31.
7) Modify varous dialog boxes to display longer device software build strings.
8) Add a right-click option to QPST port configuration to send a password string to the device.

9/19/13 QPST 2.7.410                -- NOTE: this version of QPST is not compatible with QXDM and is being removed from distribution. --
                                    -- Use QPST 2.7.411 in its place.                                                                 --
1) Add model ID 4094 = "MSM8916".
   Add model ID 4095 = "APQ8084".
2) Add support for DIAG_DSDA_PACKET_F (command code 152), streaming log packet that supports Dual SIM subscription ID.
3) Modify NV backup code to handle /nv/reg_files items up to 16K in size.
4) Fix problem in QPST Configuration main window display. If laptop is undocked or display device is changed,
   the application may position itself off the edge the new display surface

8/12/13 QPST 2.7.409
1) Added TD-SCDMA RAT selection to 3GPP BST in Roaming List Editor.
2) Increase Sahara memory dump read timeout from 2 seconds to 5 seconds.

7/11/13 QPST 2.7.408
1) Include demo script sahara_tests.pl (demonstrates Automation interface for Sahara),
   and get_qpst_port_list.pl (demonstrates how to read identification data from a device).
   See scripts for comments.
2) Increase COM port write timeout to 500 ms for slow PCs.
3) Add support for Sahara 64-bit address memory dump. This supports the ARM LPAE (Large Physical
   Address Extension) hardware.

6/3//13 QPST 2.7.407
1) Add model ID 4091 = "MSM8926".
2) Add model ID 4092 = "MSM8962".
3) Add model ID 4093 = "MDM9635".
4) Allow user to send a Sahara reset even if user selected "do nothing" in response to Sahara Hello.
5) Increase wait time for Sahara Hello from 50 to 150 ms after opening COM port.
6) Add LTE band 28, 29 to Roaming List Editor.

5/2/13 QPST 2.7.406
1) Add model ID 4089 = "MSM8x10".
2) Add model ID 4090 = "APQ8074" (apps processor only, no service programming).
3) For NAND SB 3.0, fix problem where the sequence "Sahara->load flash programmer->flash SBL1->reboot->Sahara"
   results in a stray reset command being sent after the reboot, causing Sahara mode to exit.

4/11/13 QPST 2.7.405
1) Added API to QPST Automation to return MAC address of a device that connects to QPST over TCP/IP.
   my $dev_MAC = $port_list->MACAddress($i);
   String will be empty for non-IP device connections.
2) Added support for "MSM8626" as model ID 4088.
3) Added API to return QPST Automation server process ID.
   my $pid = $qpst->PID;
4) Additional code changes to reset COM port during CE_RXOVER recovery (2.7.404 #1).
5) Add "product flavor" detection to eMMC Software Download. "Load Build Contents" will now locate any defined
   "product flavor" in the contents.xml file and prompt the user to choose a flavor. Canceling this dialog will
   revert to pre-2.7.405 behavior (if any flavors are defined use the "asic" flavor).
6) Support recursive backup lists for RF calibration item files directories.

3/13/13 QPST 2.7.404
1) To make Sahara memory dump more robust retry on CE_RXOVER error during Sahara memory read.
2) Fix a race condition that occasionally caused QPST to close a TCP/IP connection from a handset, if the
   connection was attempted during QPSTServer.exe startup.

2/22/13 QPST 2.7.403
1) Add IMEI 15th digit Luhn algorithm support to IMEI on NAS page (Service Programming). Note that the modem code running on the device
   will ignore this value and make its own check digit calculation. This change is primarily for display purposes.
2) Add support for restart timeout to automation user partition download. This is the amount of time in seconds to wait for the
   device to restart. DownloadBySettings() will return an error if the device takes longer than this amount of time.

   See swdl_9x15.pl in Qualcomm\QPST\Automation Samples\:

   $swdl_settings->SetParam("downloadTarget", "nand user partition");

   $swdl_settings->SetParam("restart timeout", "5");

   $software_download->DownloadBySettings($swdl_settings);

3) Add support to abort a Sahara memory dump that is in progress, then reboot the device.
   See notes on QPST 2.7.396. This will only have an effect if $port->LastSaharaEvent() returns state 20 (dump in progress).

   $port->SaharaAbortDumpAndReset();

1/18/2013 QPST 2.7.402
1) eMMC Software Download, support Sahara flash programmer download for "Load Configuration and start download?function.
2) NAND SB 3.0 software download, fix partition override, dialog queries user but Yes response doesn't restart the download correctly.
3) Fix problem where QPST Configuration misses USB 3.0 COM ports on some new PCs.
4) Modify NV backup to support 3 NV subscriptions for Dual Sim feature (now triple SIM).
5) NAND software download, add ability to edit SB 3.0 file paths and select only some files for download. Partition table is always selected.

12/11/12 QPST 2.7.401
1) Assign model ID 4087 to "MDM9625".
2) Fix Sahara bugs: to prevent interference with collecting a memory dump insure polling is stopped when
   reopening port in Sahara mode, return failure status to QXDM and other QPST client applications if device
   is in Sahara mode.
3) To support 9x25 devices that use Sahara to download the flash programmer, use NAND flash for images,
   and use metabuild contents.xml to define the download images, add "SB 3.0" tab to Software Download application.
4) Add feature to Sahara configuration menu (right click, QPST Configuration Ports tab) to define what
   action to perform upon receiving a Sahara Hello message: requested action, memory dump instead of download,
   download instead of memory dump, or nothing.
5) Add feature to Sahara configuration menu to specify which memory sections to dump when phone crashes and
   enters Sahara mode.

10/17/12 QPST 2.7.397
1) Provide a checkbox on the per-port Sahara configuration dialog to control automatic device reset,
   and a menu item on the per-port menu to send a Sahara reset command.
2) Fix a problem seen on some PCs where QPST Configuration Add Port does not find all devices.

10/2/12 QPST 2.7.396
1) Additional automation support for Sahara (see 2.7.395 #6).

   Retrieve last Sahara memory event.
   my $last_event = $port->LastSaharaEvent();
   Initial (when port is first added to QPST) = 1
   Dump Start = 19
   Dump in progress = 20
   Dump Complete = 21

   Enable/disable appending timestamp to memory dump folder name (1 = enable, 0 = disable, default = disabled).
   If changed this setting takes effect the next time the device enters Sahara mode.
   my $timestamp_enable = $port->EnableDumpTimeStamp();
   $port->{EnableDumpTimeStamp} = 1;
   The timestamp format is yyyymmddhhmmssiii.

   Enable/disable auto restart after memory dump (1 = enable, 0 = disable, default = enabled).
   If changed this setting takes effect the next time the device enters Sahara mode.
   my $auto_reset = $port->EnableSaharaAutoReset()
   $port->{EnableSaharaAutoReset} = 1;

   Send reset command if state machine is in Idle state. Returns 0/1 for fail/success.
   Will return failure on timeout waiting for reset response or if state machine wasn't in the idle state.
   Will return E_FAIL HRESULT if the device is not in Sahara mode.
   my $result = $port->SendSaharaResetCmd();

9/11/12 QPST 2.7.395
1) RL Editor: add support for LTE bands 23 & 26.
2) Added Service Programming support to 8974 model ID (4083).
3) Added support for 8X25Q ANDROID as model ID 4086.
4) Added configuration dialog for Sahara to QPST Configuration port list right click menu.
   This allows specification of the Sahara Configuration XML file (#2, QPST 2.7.394).
5) Added progress bar to QPST Configuration port list to show Sahara download/memory dump progress.
6) Added Automation support for Sahara. Perl syntax example:
   $port = $qpst->GetPort("COM99");            # see examples in Automation Samples on how to initialize $qpst
   $enable = $port->EnableSaharaSupport();     # returns 0 or 1. 1 means QPST will act on any download or memory debug requests from the device on this port.
   $port->{EnableSaharaSupport} = 1;           # set to 0 or 1
   $port->SaharaConfigXML($xmlPath, $oneTime); # $oneTime = 1, use $xmlPath once then forget it
   $xmlPath = $port->XmlPath();                # see QPST 2.7.394 #2 for XML file format. There is no default XML file path.
   $port->PathOneTimeUse();
   $port->{MemoryDumpFolder} = $dumpPath;      # set folder to hold Sahara memory dumps for this COM port
   $folder = $port->MemoryDumpFolder();        # return user-defined memory dump location. If blank, default is C:\ProgramData\QUALCOMM\QPST\Sahara\Port_COMxx

8/21/12 QPST 2.7.394
1) EFS Hello commands will not be sent unless the device is in a compatible mode. Sending this command when the
   device is in download mode can cause a "server busy" message for a few seconds because of command retries.
2) Support for the Sahara device protocol (see 80-N1008-1 or equivalent) is now built in to the QPST server process.
   This protocol is only supported by USB Serial ports, not TCP/IP connections. In QPST Configuration a device in
   this mode will display as "Q/QCP-XXX (Sahara Download)". This mode can only be detected (1) when the QPST server
   process starts or a COM port in this mode added to QPST, or (2) when a device enters Sahara mode on a port assigned
   to QPST. This is because the device only sends its Hello message once, as soon as the COM port is opened.

   This protocol can handle memory crash dumps and software download. On Win7 memory dumps will be stored in
   C:\ProgramData\QUALCOMM\QPST\Sahara\Port_COMxx (xx = your COM port number), and will include a dump_info.txt file
   that lists the dump regions advertised by the device.
   Sahara software download supports all images for flashless boot devices, and flash programmer download for flash boot devices.
   The eMMC Software Download application has been modified to support download of the flash programmer through Sahara.
   You will have to provide a full path to the Sahara XML download file in the "Sahara XML file" edit control.

   This is an example Sahara XML file. The programmer="true" attribute tells the Sahara state machine in QPST to
   exit Sahara mode after downloading this file, rather than wait for Sahara to reply with a Done Response of 1.
   In Sahara mode the download process is completely controlled by the device - it will request images by image_id.
   image_path is relative to the XML file. In this example all mbn files would be in the same folder as the XML file.
   A relative path would start with "\" or "..\".

<?xml version="1.0" encoding="utf-8"?>
<sahara_config>
	<images>
	<!-- Please refer mibib.h file for image ID values -->	
        <!-- programmer field is set true only for flash programmers - enandprg, nandprg, emmcbld --> 		
		<image image_id="6"  image_path="apps.mbn" programmer="false" />	
		<image image_id="7"  image_path="nandprg.mbn" programmer="true" />	
		<image image_id="8"  image_path="dsp1.mbn" programmer="false" />	
		<image image_id="12" image_path="dsp2.mbn" programmer="false" />	
		<image image_id="13" image_path="enandprg.mbn" programmer="true" />	
	    	<image image_id="21" image_path="sbl1.mbn" programmer="false" />	
		<image image_id="22" image_path="sbl2.mbn" programmer="false" />	
		<image image_id="23" image_path="rpm.mbn" programmer="false" />	
		<image image_id="28" image_path="dsp3.mbn" programmer="false" />	
	</images>
</sahara_config>

8/14/12 QPST 2.7.393
1) Change regex used to locate compatible devices to a customer-neutral form. The regex is applied against the
   device description. It affects "Add New Port" filtering and "Auto Port Addition".
   was: "Qualcomm{1,1}(.)*(Diag|QDLoader){1,1}(.)*"
   now: ".*?qdloader|diag$|(dia(g|gnostic|gnostics) .*?)"
   This regex (Perl style) is stored in C:\ProgramData\QUALCOMM\QPST\DriverData.config

   Examples of current device descriptions:
   "Qualcomm HS-USB Diagnostics 9001"
   "Qualcomm HS-USB Android DIAG"
   "Qualcomm HS-USB Android DIAG 9018"
   "Qualcomm Diagnostics Interface 6000"
   "Qualcomm HS-USB QDLoader 9008"

2) Modify "Add New Port" dialog to display device description, and (if available) the device's USB serial number.

7/20/12 QPST 2.7.392
1) Add handling of DIAG_SSM_DISALLOWED_CMD_F response from device.
2) NV Backup, move total progress to 50% after completion of NV items. Advance it to 100% on final success status.
   This gives better feedback to the user, otherwise it looks like backup is hung during the EFS file backups.
3) Increase NV restore timeout waiting for Diag after reset from 75 to 180 seconds.

7/2/12 QPST 2.7.391
1) Add support to RL Editor for bands 18-21 to 3GPPBST (File->New->3GPPBST (Alt+G)).
2) Add support to QPST server for Sahara memory read command.

6/11/12 QPST 2.7.390
1) Roaming List Editor: correct error when saving TOT table with > 5 RATs.
2) Fix problem in port auto-add with latest USB host driver. The USB device composite name has changed
   slightly preventing auto-add from finding the device.

6/5/12 QPST 2.7.389
1) Add support for LTE Available File (LAF file type) to the Roaming List Editor.
2) Add partition override support to Software Download user partition download. GUI version will prompt for
   permission to override the existing partition table. In the scripting interface set "overridePrtnTable"
   to 1 to override.
3) Add support to back up user-defined NV items. These are NV items with item numbers > 7232 and < 65536.
   Use a text editor to create a file named nvextra.nvl in the QCN backup folder. Example file format:
   # comment
   8000,8002,8010-8020
   8030  #comment
4) Add swdl_9x15.pl software download sample script to installer.

5/15/12 QPST 2.7.388
1) Add support to detect Sahara download mode.
2) Remove obsolete/deprecated feature support from Software Download app:
   Disable "use custom armprg" control.
   Disable automatic usage of old boot download on the NOR download page.
3) Correct WCDMA and GSM TMC offline test. QPST was not correctly detecting the state change on a directed
   offline or download mode change.
4) Add new model support:
   Add model ID 4083 (MSM8974) - device detection only.
   Add model ID 4084 (QSC1105 C+G) - software download and service programming.
   Add model ID 4085 (QSC1215 G) - software download and service programming.

5/1/12 QPST 2.7.386
1) Add support for GSS device as model ID 4082.
2) Add TDSCDMA as RAT 11 to Roaming List Editor tech order table.

4/2/12 QPST 2.7.385
1) Add flash programmer support for QSC1105.
2) Add emergency download support for NOR flash.
3) A missing banned_commands registry key is now interpreted as FALSE instead of TRUE. The devices supported by this registry
   setting are obsolete. See QPST 2.7.247 release notes in this file for details.
4) Fix crash on NV restore when QCN file is closed during device reset.

3/19/12 QPST 2.7.384
1) Fix case where device is not always detected by QPST on a transition from "not ready" to "ready", if this was preceeded by a very short
   (few seconds) "ready" state. In this case the thread that reads NV item *.conf files does not terminate correctly during the short ready state.
2) Fix case where Automation phone count ($port_list->PhoneCount) may return zero phones (or no more than one less that the full count) if an
   APQ device is connected. This is because NV reads on the APQ return "bad command".

2/24/12 QPST 2.7.383
1) Fix case in memory debug app where start address is 0xC0000000 and length is 0x40000000.
2) Fix crash in Service programming when configuring IPv6 address.
3) Add support for 8x30 model IDs.
4) Modify change introduced in QPST 2.7.114:
   polling_timer_interval_ms [600, 10000]
5) Increased Dual SIM NV item read/write timeout from 2 to 8 seconds.

1/25/12 QPST 2.7.381
1) eMMC Software Download fails with "Failed to open user partition data file". Modified file search code to insure found files include a full path.
2) Support for User Partition Download to NAND flash, which is used for NAND Secure Boot 3.0, is available on the QPST Automation server.
   The Perl script swdl_9x15.pl in the QPST Automation Samples folder provides a basic example of using the User Partition Download interface.

   The example does not perform a full download to a device and must be customized by the user for the device and file paths. Please examine the
   Perl script for details. At minimum you will have to modify these settings:

   Set this parameter to your list of search directories:
     $swdl_settings->SetParam("searchPaths", "e:\\Phone_Builds\\test_data\\;e:\\Phone_Builds\\test_data2\\");

   Set this parameter to the partition names and files you want to download. The files must exist in one of the search directories:
     $swdl_settings->SetParam("userPartitionList", "0:DSP1=dsp1.mbn;0:DSP2=dsp2.mbn");

   If the device is in Diagnostic mode, you can let QPST pick the flash programmer (based on the device�s model number), or you can override this
   behavior. See the comments in the �IsKnownConfiguration = true?branch. The flash programmer must exist on the search path.

   If the device is in download mode or is unknown to QPST ("IsKnownConfiguration = false" branch) you will always have to specify the flash programmer.

   As with the GUI version of User Partition Download, NV backup/restore isn�t supported. Please see the other Perl script examples for backup/restore.

3) In EFS Explorer, copying the contents of an EFS file on a phone with a slow file system can result in occasional duplication of read data.
   The file read code will now check for this condition and try to read the next file block up to 3 times. Persistent read timeouts will still cause
   the read to fail.
4) NV item backup: NV item read/write timeouts have been increased. Some devices have NV item read times that intermittently reach 2+ seconds.
5) This release provides initial support for phone subsystem restart (SSR).
6) Added a DeviceName property to the Automation server PortProxy object. This returns the device name show in the QPST Configuration application.

12/19/11 QPST 2.7.380
1) eMMS SW Download: add support for eMMC download using flash programmer instead of mass storage,
   so all physical partitions can be programmed ("Load Configuration" button). Mass storage can only
   program physical partiton 0. This also provides ONE-TIME creation of GPPs on a eMMC device and the
   designation of a boot partition. Programming through the flash programmer also means users
   don't need admin rights (as they do for mass storage) to use eMMC SW Download.
2) eMMS SW Download: fix problem where mass storage devices don't always enumerate with a driver letter and
   download fails with "Failed to find a drive letter for the device".
3) Add support for model ID 4075 (8X25-ANDROID) as 1x/EVDO+UMTS device.
4) EfsExplorer: Fixed problem where phone would disappear from QPST for 1-2 seconds at the end of a file
   copy to phone.
5) Phone trace using settingmgr info instead of registry
6) Quick phone connection issue (fix crash)
7) SSR change for Serial Port type
8) SSR support for TCP/IP type
9) add DeviceName property on PortProxy
11/29/11 QPST 2.7.379
1) Use "QPSTServer.exe -CleanStartServer" to clear the QPST configuration file of all settings. Use this option
   if the QPST server crashes on startup.
4) Add ability to set baud rates for UART (RS-232) type PC COM ports. Use the QPST Configuration app Ports tab
   and right click on a port. Select Baud Rate to open the baud rate dialog. Note- this menu item is only present
   on UART-type COM ports. Select the baud rates QPST should use on this port. If no rates are selected 115200
   will be used. QPST will try these rates in an attempt to connect to the device, so the more rates you enable
   the longer it may take to establish a connection to the device. Most PC RS-232 ports will NOT work at rates
   above 115200, you will have to install a COM port that can handle these data rates.
5) BST3GPP editor - add support for bandID25.
7) NV backup - move RF cal items 5080 through 5087 from 2-index to non-indexed.
8) Add sample for eMMC software download automation.

10/27/11 QPST 2.7.378
1) Add support for QSC11x5 CDMA only (4073) and CDMA+GSM (4074).
2) Fix problem with eMMC Software Download not correctly patching addresses > 8 GB.

10/13/11 QPST 2.7.377
1) Fix crash when QPSTServer.config are NULs (bad format).
2) Add model ID 4072 = "APQ8064". Apps processor only, no service programming.
3) Change flash programmer name from nprg9615.hex to nprg9x15.hex.
4) Add emergency download support for user partitions.
5) Fix case where user partition download fails if the flash programmer is on a file share.
6) Fix error case when add port is used but no port is specified.
7) Fix case where restoring an EFS file doesn't work if the file was modified by QXDM.
8) In Service Programming BC SMS fix case where if user enters 32 as the service type it get written to NV as 4096.
9) Fix case where a phone will stay in "no phone" state if the phone takes > 20 seconds to reboot.
10) Take care of cases in eMMC Software Download where we try to lock the disk volume but the drive letter isn't available.
11) Fix "server busy" issue when a device connects but it's modem isn't running.
12) Insert more status message in Memory Debug app so that we can see why fast unframed dump failed.

8/17/11 QPST 2.7.375
1) Add support for MDM9615 (model 4070). Rename model 4068 to 7627A-ANDROID from SURF7627A.
   Add model 4071 (7627A-WinMob). Add 1x/UMTS service programming to 4068 and 4071.
2) eMMC Software Download: Don't try to lock volume if drive letter not present.
   Devices that use GPT will not mount and get a drive letter assigned.

7/22/11 QPST 2.7.374
1) Added missing file to installer to fix Service Programming problem in 2.7.373.
2) For eMMC Software Download, abort the download if a sparse="true" directive is present.
   Sparse files cannot be downloaded with QPST, only with fastboot.
3) Began the process of moving QPST application and server settings from registry to
   configuration files.
4) Added more error checking to EFS Explorer file drop code.

7/5/11 QPST 2.7.373
1) Add support for SURF8960 model ID 4069.
2) Fix issue with Port Enable/Disable for IP Ports.
3) NAND Software Download: Correct flash programmer descriptions for 7225A, 7625A, 7227A, and 7627A.
4) Roaming List Editor: Added two new bands LTE 24 and LTE 25.
5) eMMC Software Download:
   - Fix problem where some file names print as "(null)".
   - Add support for Meta Build contents.xml file ("Build Contents"). The contents file will provide the path for the
     rawprogram and patch files, extra search paths, and names of flash programmer and boot image files.
   - Ignore unexpected elements in schema.
   - Support zeroout directive to zero parts of partitions.
   - Allow usage by app of "orderly" as well as surprise removal storage devices.
   - Add support for computations in the <patch> (CRC32 for GPT support), <program>, and <zeroout> directives.
6) EfsExplorer:
   - Enable reset button in Efs Explorer even if target not in offline mode.
   - More text description in Mode column for Efs Explorer 
   - Modify the list context menu of Efs-Explorer.
   - If the proposed item file size copy is > 2048 bytes, warn the user and bail out.

05/12/11 QPST 2.7.371
1) Add model IDs 4065 (SURF7225A), 4066 (SURF7625A), 4067 (SURF7227A), 4068 (SURF7627A).
2) eMMC software download: Only allow programming of physical partition 0.
3) eMMC software download: Update app to work with positions/sizes > 4 GB.
4) Increase max DM packet send size to 4k and receive to 8k.
5) PRL Editor: Allow .bin and .rl* extensions to be used.
6) Send EFS Sync command before reset.
7) eMMC software download: ignore unknown name/value pairs instead of aborting download.
8) eMMC software download: add command line support for patch file and devices > 4 GB.

04/05/11 QPST 2.7.370
1) Support for eMMC software download has changed to "raw partition" support. In the XML file, <image> is no longer a valid section. The <data> section is now used with raw partition data. A seperate image patch file is also supported, it must use the <patchs> section.
2) Download dsp1 and dsp2 by default on all MDM9K devices (NAND flash download).
3) Update DLOAD max protocol version to 9 to support command 0x19/0x1A - connection cookie.
4) Fix false error that occurs when a phone is switched to offline or download mode.
5) USB serial ports are now added automatically to the QPST configuration added the virtual port is created.
6) QPST eMMC software download will now follow a WP7 device from a TCP/IP connection to USB serial (transition from Diagnostic to Download mode) if the AMSS build supports connection cookie commands.
7) Adding model IDs 4063, 4064. Only provides device identification, no service programming or NAND/NOR software download.
8) eMMC software download - fix crash when copying a small (< 1 block) file to the device.
9) Sending Sync No Wait (AMSS file system sync) when phone is reset. Note that this may be removed in a future QPST release since AMSS should take care of this.
10) Added new bands and increased the max band limits for LTE.
11) eMMC software download - Change radio button selection of what to download, to checkboxes.
12) Add eMMC rawpartition support to software download automation interface. Removes write protect group size setting, always uses physical partition 0, adds device patch file support.
13) NAND software download - Increase the partition table size to 1024.

02/01/11 QPST 2.7.368
1) Fix bug that caused high-speed memory debug to hang.
2) On eMMC SW download, don't require partition.mbn if eMMC boot image is present.
3) Don't send partition table with eMMC software download.
4) Fix crash in TCP/IP server when a command (i.e. 0x29) does not get a response.
5) Fix bug where Automation clients can't get EFS handle.
6) Update max supported DLOAD protocol version to 7.
7) Add code to translate eMMC software download numeric error codes to text strings.

12/10/10 QPST 2.7.367
1) Security fix in several applications to prevent Dll Loading and Binary Implant attacks.
2) Move all the logging files to All Users/Application Data/Qualcomm/Qpst folder.
3) Open user guide when application help is selected.
4) EFS Explorer:
   - fix issue with drag drop of File on Tree.
5) Update mdb_saveallregions script to show use of UnframedMemoryReads
6) Memory Debug App:
   -fix 'Server Busy' error with 'Get Regions' of Memory Debug
   -increase speed of memory debug 'Save Regions' through code refactoring
   -fix Memory Debug application logic - use 'legacy' memory debug protocol if user unchecks 'High-speed (unframed)'.
7) Modify model ID 4055 to use NPRG6615.HEX flash programmer instead of NPRG6695.HEX.

11/3/10 QPST 2.7.366
1) Service Programming: Added GERAN CAP to LTE-NAS page.
2) Display Capture
   - Display Capture was initially just searching the primary file system. Made changes to ensure that Display Capture
   now searching both the file systems and uses a resolution if the file is present in both file systems.
   -"Save To" option was enabled always even if nothing was available to save. Now, it is modified to save only when
   display has been captured.
3) Add support for model IDs 4060 ("MSM8260", UMTS), 4061 ("MSM8660", Multimode), 4062 ("APQ8060", No Modem).
4) EfsExplorer
   - Send cache sync command after writing a file to immediately commit it to flash.
5) RLEditor
   -Fix for bug in the subnet Id display of mcc-mnc based records.
   -Expand the number of allowed channels for CDMA from 32 to 50.
   -Save in Text View was failing on Windows-7.
6) Memory Debug
   - Highspeed (unframed) memory dump protocol can now be disabled. This protocol is only compatible with
   Qualcomm (and Qualcomm compatible) USB host drivers.
7) eMMCSwDownload
   - Disable DTD loading (ignore DOCTYPE statements).
   - Allocate requested space for "empty" partitions rather than allocate
     placeholder (write protect group size) space.
   - Use a partition table size of 512 bytes instead of 8192.
   - Reset device at end of download if download started on COM port.
   - Add NV backup/restore. The output file goes into the all users common apps folder.
     The qcn file is named after either the IMEI, MEID, or ESN depending on which is active.
   - Change default button from Exit to Load XML.
   - Change "Load build to EMMC device" button text to "Download".
   - Command line switches:

   Note: emmcswdownload.exe is a Windows GUI application. When you start a GUI application (for example
   "notepad") in a command window you will get a new command prompt as soon as the application starts.
   The command window does not wait for the application to terminate before displaying a new command prompt.

   1) List all mass storage devices to a file.

   -l <filename>   : list devices in csv format to filename (same fields as in the GUI)

   example:

   >emmcswdownload -l \tmp\devices.txt
   >type \tmp\devices.txt

   2) Build an image file.

   -f <filename>   : direct output to filename instead of a mass storage device

   -f can be used alone or with all of these additional three switches to
      take the build parameters from the command line instead of the GUI:

   -s <size enum>  : mass storage device size = { "1G", "2G", "4G" }
   -g <size enum>  : write protect group size = { "4M", "8M", "16M", "32M",
                                                  "64M", "128M", "256M", "512M" }
   -x <filename>   : XML file path

   Optional swithes for -f -s -g -x combination:
   -p <searchpath> : search path = path1;path2; ... pathn

   example:

   >emmcswdownload -f \tmp\test.bin -x c:\eMMC\partition.xml -s 1G -g 64m -p E:\eMMC1\;E:\eMMC2\

   3) Copy image file to device.

   -i <filename>   : specify input file name to write to device
   -w <devicename> : device to write to (drive letter or device name in "\\?\usbstor# ..." format)

   Note: Use double quotes (") around a device name. Not necessary for a driver letter.
   You can get a list of devices with the -L switch.

   example:

   >emmcswdownload -i c:\tmp\test.bin -w k:\

9/15/10 QPST 2.7.365
1) Increase the download wait timeout to 45s for Velcro.
2) Emmcswdownload:
(a) Add button to emmcswdownload to switch mobile to download mode.
(b) Scroll display to bottom of screen for each line.
(c) Handle GUID_IO_DISK_LAYOUT_CHANGE notification for Win7.
(e) Switch from using dbl/osbl to single boot image file.
(d) Remove layout description window, just use one window for output.
(e) Reset progress bars.
(f) Send DLOAD cmd w/o waiting for mode change (for tcp/ip connections).
3) RLEditor:
(a) Fix issue with empty MCC/MNC Field.
(b) Change to Mcc-Mnc based Sys Record for reserved field.
(c) BC3 1.8GHz for UMTS renamed to BC3 1.7GHz; GERAN BAND_ID 8 renamed to PCS 1900
(d) all explicit selection of "filler" record type for MLPL records.
4) Software Download - Fixed the issue in Multi-image page of software download [copy paste of path not working unless Advanced is pressed].

8/3/10 QPST 2.7.363
1) Added new command line switches to eMMC Software Download. Note that because this is a Windows app and not a console app text
   error output from command line operations will go to the parent cmd.exe window. The output cannot be redirected to a file.
   -L <filename> : list all storage devices to filename. Will list the same parameters as the GUI as comma-separated-values (with quotes around values).
   -I <filename> -W <device> : copy image file built with -F switch to device. Device can be a drive letter or a device path.
     Device path should be enclosed with quotes.
2) Modify device layout produced by eMMC Software Download.
   Modify EBR layout from EBR1, data1, EBR2, data2,... to EBR1, EBR2, ..., data1, data2.
   Move data1, data2, ... each to its own write protect group, and group all the EBR1, EBR2, ... to follow the primary partition data.
   Move the primary partition data so it follows the MBR.
3) Add blank flash programming option to eMMC Software Download. The application now has two programming modes.

(a) Program boot loaders and MMC device

This is for blank flash programming. This mode will download partition.mbn, dbl.mbn and osbl.mbn, and then copy files to the eMMC device. 

Browse for a device in download mode 
Set a flash programmer file name. Default is EMMCBLD.HEX. It must exist on one of the search paths. 
Set trusted mode as appropriate 
Set "Write Protection Group Size" THEN "Load XML def". Order is important here.
Enable any additional search paths you want, and then use browse or drag/drop of the folder (or a file in the folder) to populate the control. 
Press "Load build to EMMC device" 

It should go through the flash programmer steps, and then program the first mass storage device that shows up after the device reset.
You will not see any progress bars until the application gets to the eMMC programming.

(b) Program MMC device only

This is the original programming mode for this application. 

Select the device you want to program from the list of devices. 
Set Write Protection Group Size THEN Load XML def. Order is important here.
Enable any additional search paths you want, and then use browse or drag/drop of the folder (or a file in the folder) to populate the control. 
Press "Load build to EMMC device" 

4) PRL Editor changes:
  - Changed the layout of GWL Acquisition Record.
  - Fixed print/unprint for GWL Acquisition record after previous changes.
  - changed enum mapping for Bst3Gpp
  - changes to reflect change in 3GppBst [ reverted back to previous enum for LTE ]
5) EFS Explorer changes:
  - Copy Item File from PC to UE.
  - Copy Item File from UE to PC.
  - Drag-Drop for Item Files between PC and UE.
  - Resolve crash of EFS Explorer when double clicked in empty area
6) Service programming - Display MEID data and Build data properly.

7/8/10 QPST 2.7.362
1) Add support for MDM6615 (model ID 4055), MDM6215 (4056), MDM6610 (4057), MDM6210 (4058), and Gobi3000 (4059).
2) See QPST\Automation Samples\swdl_DownloadBySettings.pl for sample code and comments on a new
   software download automation interface. Also swdl_DownloadBySettings.vbs for VB sample code.
3) Add more NV items to the NV item backup-always list.
4) Change timing for DLOAD on Velcro/Fusion "Dual Device". Switch both devices offline first,
   then DLOAD one at a time with a 250ms delay in between.
5) Adding apps, apps boot, WinMobile, dsp1, dsp2, adsp, tzos images to DownloadBySettings. See swdl_DownloadBySettings.pl.
6) Add NV items 7167-7232 to NV backup.
7) Add QCNView support for SIM 1.
8) Fix problem where devices with an ESN > 7FFFFFFF always displayed as 7FFFFFFF in QPST Configuration.
9) Display phones with unknown model IDs as "?".
10) PRL Editor changes:
    (a) Change in Mlpl Structure 
    (b) Crash in Mcc-Mnc SID/NID when num SID/NID was changed.
    (c) Text View in Mcc-Mnc printed unrequired reserved field.
    (d) Changed the working on OnSave and OnSaveAs functionality.
11) Fixed bug in EFS Explorer Drag Drop. Drag-Drop was not working in the "unpopulated" area of the list. (CL 361000)

6/11/10 QPST 2.7.361
1) PRL Editor changes:
   Bst3Gpp Mcc field is changed from 16 bits to 12 bits BCD and four bits are padded.
   Add version field to Technology Order Table, update the enum mapping. 
   Fix the print and unprint which were broken after previous standard changes.
   Removed the headers used for Plmn file types.
2) QCNView changes:
   Support to display Provisioning NV Items.
3) Service Programming changes:
   Added Temporary Plmn Disable to Lte Nas in Service Programming App.
4) Software Download changes:
   Add preliminary Software Download support for Fusion/Velcro "Dual Device" that contains two chips.
5) Automation interface (DownloadBySettings):
   Add "boot only" option for SB 2.0, just download the boot files.
   Add option to set restart timeout.

4/30/10 QPST 2.7.360
1) Installer missing the QPST Configuration app menu option in the tray icon.
2) Modified behavior of Service Programming LteNas tab.
3) PRL Editor:
   Changed Mcc-Mnc encoding/decoding in Plmn and Mlpl to synchronize with changes in AMSS code change. 
   Issue while deleting row in one particular case detected during testing for Plmn.
   MCC-MNC for mcc-mnc based records were in binary previously. Changed it to BCD encoding.
   Reflecting the change in MLPL structure for the reserved field.
   Adding support for 2-digit Mnc for Mlpl, mcc-mnc based and Plmn-based records.
   Added redundant fields in BST-3GPP which enables testing.
   Fixed a couple of UI related issues detected during testing.
   Fixed the wrongly interpreted reserved field in mcc-mnc based records.
   Changed Tab Ordering in Dialogs.
4) Add NV Backup support for NV items 7140-7166.
5) Add DownloadSettings object to the automation interface. Add implementation of DownloadBySettings.
6) Allow Navigation through Symbolic Links in EFS Explorer. Show the pointed location in Symbolic Link Properties.
7) Drag Drop support for Directories in EFS Explorer.
8) Solve startup problems when server already started.
9) Update Service Programming BC-SMS for new service values for CMAS.
10) Add support for high speed memory debug protocol. This will only be used if the phone supports it, otherwise memory debug will fall back to the original protocol.

3/25/10 QPST 2.7.359
1) Change ADSP default file name to adsp.mbn and user partition name to 0:QDSP_Q5.
2) Add software download support for Symbian images TZOS (trust zone), ROFS1, ROFS2, and ROFS3.
3) Added Service Programming support for LTE NAS provisioning items.

2/12/10 QPST 2.7.358
1) Modified installer to configure executables for compatibility mode on Win7.
2) Fixed a problem in Automation interface EFS directory enumeration.

2/5/10 QPST 2.7.357
1) Modified Service Programming and Software Download for Dual SIM AMSS builds.
2) Add port option to enable/disable AT commands that are sent to a modem port to switch it to Diag mode.
   On some AMSS versions switching the modem port to diag mode will cause a phone crash.
   You can access this through the QPST Configuration application on the Ports tab. Right click on
   an active port (UART/USB only) => "Switch modem port to diagnostic mode" will enable the behavior
   in previous QPST releases.
3) Change multi-image open timeout from 10 to 40 seconds for slow flash chips.
4) Modify factory image download to handle large image files.
5) Added Reserved bits for MCC-MNC SubnetId type
6) Added emmcbld.hex flash programmer for eMMC support. No model ID is associated with this device at this time.
7) Added preliminary release of emmcswdownload.exe to support phones that use eMMC devices in place of
   NAND/NOR flash chips. To use the application:
   a) Select a mass storage device that shows up as "surprise" removal and writable.
   b) Select the write protection group size.
   c) Use Load XML Def to load the XML description file. Do not include a DTD unless you have provided one.
   d) Press the build button to build the image on the device you selected in step (a).

12/4/09 QPST 2.7.356
1) Use NPRG7X30 flash programmer for MSM7x30 devices.
2) Update NV support to backup items 6835-7139.
3) Always back up CDMA roaming list files regardless of type of phone connected.
4) Add Chinese and Korean to asian language checking for Software Download layout.
5) Added NV_PREF_FOR_RC_I to NV backup.
6) Adding preliminary Service Programming support for MDM9K.

10/26/09 QPST 2.7.355
1) Add ADSP image download support. The image is downloaded as a user partition,
   so it will only work if the partition is defined and marked as writable in partition.mbn.
2) Fix EFS Explorer dragging issues.
3) Update Software Download application to size itself for the controls in Japanese versions of Windows.
4) Change the value used for "Multi-RmNet + modem" from 3 to 6 on the RmNet "USB current device" control.

9/30/09 2.7.354
1) Add support for non-modem build polling command (DIAG_SUBSYS_CMD_F / DIAG_SUBSYS_PARAMS / 3).
2) Update model IDs 14, 4036, 4037, 4038 to refer to the device as MSM instead of QSC.
3) Add support for NV items 6486-6834.

8/31/09 QPST 2.7.353
1) Fixed problem where PPP password fails when password set through service program app.
2) Fix problem where download of partition file randomly fails.
3) Modify maximum receive size to handle 8192 bytes (16384 HDLC encoded).
4) Rename flash programmers for QSC6195, QSC6295, and QSC6695 to NPRG6695.HEX.
5) Remove error when 'OK' is pressed on Add New Port dialog when no ports are selected in list.
6) Increase flash programmer size to 500K for 7627 builds.
7) dded Android models 4047, 4048, 4049 for 7x30.
8) Remove NV_SECTIME_TIME_OFFSETS_I from NV backup because it is no longer writable.

5/28/09 QPST 2.7.349
1) Add timestamps to DLoad_COMx.dbg file.
2) Removed efs_gen from the installer. It is now shipped seperately from QPST.
3) Software Download: Updated NV backup for items 6273-6481.
4) Software Download: Use count stored in NV item 1015 to decide how many 1014 items to back up.
5) Software Download: Provide ability to set PRL restore conditions to (1) always restore, or (2) restore only if RTRE
   item exists and is set to NV.
6) Memory Debug App: Changed NAK processing to report reason code number.
7) EFSExplorer now displays the files in a root directory of a phone.
8) Add support for QSC6695 as model ID 4035.
9) Add all GPS NV items to NV Backup.
10) Update eHRPD support by adding IMSI and Op field to Service Progamming.
11) Update MIP V6 for secondary HA, HoA prefix length in Service Programming.
12) In Software Download skip the FSBL image if zero length or file doesn't exist. This image is optional on some AMSS builds.
13) Modify Service Programming MIPV6 to latest requirements.
14) Prevent 'Server Busy' dialog from popping up during large file copies in EFS Explorer and Automation Server.
15) Add Software Download support for models:
ID 4036 = 7630 MM
ID 4037 = 7230 UMTS
ID 4038 = 7530 C2K
ID 4039 = SURF-QSC6695 (2)
ID 4040 = SURF-QSC6295
ID 4041 = SURF-QSC6195
ID 4042 = FFA-QSC6695
ID 4043 = FFA-QSC6295
ID 4044 = FFA-QSC6195.

3/11/09 QPST 2.7.341
1) Added support for new devices:
ID 4010 SURF1xxx-1105
ID 4011 FFA1xxx-1105
ID 4012 SURF1xxx-1100
ID 4013 FFA1xxx-1100
ID 4014 SURF1xxx-1000
ID 4015 FFA1xxx-1000
ID 4016 SURF1xxx-1500
ID 4017 FFA1xxx-1500
ID 4018 SURF1xxx-1600
ID 4019 FFA1xxx-1600
ID 4020 SURF1xxx-1700
ID 4021 FFA1xxx-1700
ID 4022 SURF6280-RTR6250-Polar2
ID 4023 FFA6280-RTR6250-Polar2
ID 4024 SURF7627-WinMob
ID 4025 SURF7200A-MFLO
ID 4026 FFA7200A-MFLO
ID 4027 FFA7201A-MFLO
ID 4028 SURF7600-MFLO
2) Added NV Backup support for items 6256-6272
3) Add QPST Configuration feature to control how IP/port are used to map to a COM3000x port. You can use just the IP
   address (which is the way it has worked up to now) or use IP plus port number. The second mode will only work
   correctly if the mobile always uses the same TCP/IP port when it starts. The first mode will work for all devices
   but limit you to one device per IP address.
4) Added factory image download to Software Download application.
5) Updated efs_gen tool to support EFS version 64 (VU 64).
6) Removed Gang Image tool from installer. This tool is no longer supported. Please use QFIT in its place.
7) Modified EFS Explorer to allow user to select which file system to browse. However current phone software builds
   only support one filesystem. For MSM 7xxx that use BREW you can access the Apps filesystem, and for WM/Linux builds
   it is the Modem filesystem. For MSM6xxx the mobile only has one filesystem. For future AMSS builds that enable two
   filesystems you can start two instances of EFS Explorer to view both filesystems.

11/19/08 QPST 2.7.335
1) WLEditor changes:
   -System Records now contain columns for Handoff Permitted, Hidden SSID and WLAN Sec Mode.    
   -Profiles now contain columns for Server Name Len and Server Name. These columns are active when Authentication
    is set to TLS, PEAP or TTLS.
   -When saving, Profile Encryption and Authentication types are validated against WLAN Sec Mode of referring System
    Records.
2) Service Programming IWLAN bitmask items have been change to a bitmask control.
3) Fixed multi-image download file path control, which would occasionally report an incorrect path.
4) Added NV backup support for items 5895-6255.
5) Service Programming: Changed NV value for 4GV wideband setting from 0x8028 to 0x46.
6) Added support for new model IDs:
ID 1, FFA7527-WinMob
ID 2, FFA/SURF7630
ID 3, FFA/SURF1600-Linux
ID 4, FFA/SURF1700-WinCE
ID 200, SURF/FFA7600-Linux
ID 201, R-MSM7630
ID 242, FFA/SURF1500-Linux
ID 245, FFA/SURF1600-Linux
ID 246, FFA/SURF1500-Linux
ID 4002, SURF7625-Linux
ID 4003, SURF7625-Linux
ID 4004, FFA7627 Multimode
ID 4005, FFA7527 1x
ID 4006, FFA7227 UMTS
ID 4007, SURF7627 Multimode
ID 4008, SURF7527 1x
ID 4009, SURF7227 UMTS
7) Modify Service Programming for model ID 127 to support UMTS System page.
8) Added "Use Emerg. Host D/L" feature to Software Download. This feature will only work with chipsets
that support emergency host download, and allows you to download new images to a mobile device that
has an empty or corrupted flash device. If you enable this feature Software Download will
attempt to use a special flash programmer (eNPRGxxxx.hex) that is chipset-dependant.
9) Added support to Service Programming for eHRPD.
10) Added efs_gen tool to QPST installer (see separate readme file for details).

7/3/08 QPST 2.7.320
1) Backup all Bluetooth NV items in Software Download.
2) Add support for NV items 5701-5894.
3) Update RF NV Manager to version 1.4.31.
4) Added support for Mobile IPv6 to Service Programming.
5) Added support for bandclass bits 16:63 to UMTS Service Programming.
6) For Automation interface method CopyPCToPhone, change share mode of PC file from exclusive to
deny write to allow other reader applications to open the file.
7) The synchronization code added to 2.7.307 does not work with older phones. They return an error
if the max protocol version in the Hello command isn't 2. Modified synchronization code to use 2
for this parameter.
8) Added support for SURF8200A-RTR6285 as model ID 8.
9) Add Service Programming support for MSM6295.
10) Add Service Programming support for Gobi 2000 model ID 12.
11) Add Service Programming support for models 5 (FFA/SURF 7625 WinMob),
    6 (FFA/SURF 7600 WinMob), 7 (FFA/SURF QST-1105 Linux).
12) Added band classes 18 and 19 to generic cdma and 17, 18 and 19 to generic hdr to PRL editor.
13) Increased timeout to transition to download mode from 30 to 45 seconds.
14) Added support for IWLAN (wireless LAN interworking) to Service Programming.

5/22/08 QPST 2.7.312
1) Added NV backup of items 5599-5700.
2) Added support for Secure Boot 2.0 to MultiImageDownload Automation function.
QPST will use the model number to decide which download protocol (standard
multi-image, or SB 2.0) to use.
3) Change model 13 from SB 2.0 to multi-image boot.
4) Add Service Programming support for MSM7625 model 13.

4/22/08 QPST 2.7.310

************************** IMPORTANT **************************

1) During NV item backup a Microsoft file API was returning errors once the count of stored
NV items grew above a certain limit. This limit was dynamic and unpredictable. This QPST version
uses a different algorithm to store items in the QCN file to work around this problem.

QCN files created with this QPST version are not compatible with QPST software versions released
prior to version 2.7.310. This version can read NV items from pre-2.7.310 QCN files, but QPST versions
older than 2.7.310 can not read NV items from QCN files produced by this QPST version.

QCNView will identify new QCN files as having major version 2. The original QCN file format used
version 1.

If you are providing QCN files produced with this QPST version to other QPST users that have an
older QPST version installed, please also provide the installer for this version.

************************** IMPORTANT **************************

2) Added Service Programming support for QSD8250/8650 models.
3) Updated RF NV Item Manager to 1.4.30.
4) Added NV item backup support for items 5285-5598 to Software Download.
5) Added support for "raw" Apps file system download to Software Download.
6) Add Download and Provisioning support for model 26 (QST1105).
7) Add Provisioning support for models 22, 24 (QSC1100), and 23, 25 (QSC1110).
8) Add combo box to Download to allow user to select boot method (SB 1.0 a.k.a multi-image,
SB 2.0) for a mobile already in download mode.
9) Add support to Service Programming for IPV6 Neighbor Discovery provisioning.
10) Add Software Download support for model 13 (FFA/SURF 7625) and 14 (QSC 7630).

3/5/08 QPST 2.7.303
1) Added Software Download support for:
model 15 = SURF/FFA QSD8250 Rev 2.0
model 16 = SURF/FFA QSD8650 Rev 2.0
model 17 = SURF/FFA QSD8250 Rev 1.0
model 18 = SURF/FFA QSD8650 Rev 1.0
model 22 = SURF-QSC1100
model 23 = FFA-QSC1110
model 24 = FFA-QSC1100
model 25 = SURF-QSC1110
2) Added Service Programming support for:
model 19 = QSC6270/QSC6240
3) Added support for model 29 = FFA/SURF6290.

1/31/08 QPST 2.7.301
1) Roaming List Editor: Added UMB acquisition record. Added MCC-MNC based system record.
2) Increase wait time for download mode from 15 to 30 seconds.
3) Added NV backup support for items 5270-5484.
4) Updates RF NV Item Manager to 1.4.28.
5) Added support for DSP download to standard multi-image download.

12/11/07 QPST 2.7.295
1) Added support for NV items 5046-5269.
2) Added support for PRL files over 8k.
3) Add preliminary support for Secure Boot 2.0 and MSM7800.
4) Roaming List Editor: Added UMB acquisition record. Added MCC-MNC based system record.
5) Update RF NV Item Manager to 1.4.27.

9/21/07 QPST 2.7.293
1) Fixed problem where QPST port server could crash if mobile reconnects to USB during polling
   for a data modem.
2) Added NV backup support for items 4935-5045.
3) Add check to NV backup to make sure item returned was item requested.
   This error will produce the message "NV item received was not the one requested - see DBG file".
4) Update RF NV Manager to version 1.4.26.
5) Add support for concatenated PRL write to Service Programming.
6) Add -q command line switch to QCNView for quite mode. Works like -s but doesn't
   display any dialog boxes.
7) Fix problem where QPST server may crash during auto shut down if it has a TCP/IP client connected.

8/22/07 QPST 2.7.290
1) Updated Service Programming default values for IPv6.
2) For Automation interface phone reset function, test phone status before sending offline command.
   Offline will fail if phone is in download mode causing phone reset to fail.
3) Memory debug application automation - changed SaveAllRegions function to return NOERROR on success.
4) Update Service Programming to add DVB-H support to MSM6280 and 7200.
5) Service Programming will now write both the legacy and new GPS IP address and port NV items.
   It will attempt to read both and display whichever one returns data, giving priority
   to the new NV items.
6) Added NV backup support for items 4795-4934.
7) Updated RF NV Item Manager to version 1.4.25.
8) Added support for new phone IDs:
ID, name, flash type, flash programmer name
31,FFA/SURF7225,NAND,NPRG7225
32,FFA6246-RTR6285-A2,NAND,NPRG6246
33,SURF6246-RTR6285-A2,NAND,NPRG6246
37,FFA6175-RF6500 (NOR),NOR,APRG6800
38,SURF6175-RF6500 (NOR),NOR,APRG6800B
39,FFA6175-RF6500 (NAND),NAND,NPRG6800
40,SURF6175-RF6500 (NAND),NAND,NPRG6800B
41,FFA6575-RF6500 (NOR),NOR,APRG6800
42,SURF6575-RF6500 (NOR),NOR,APRG6800B
43,FFA6575-RF6500 (NAND),NAND,NPRG6800
44,SURF6575-RF6500 (NAND),NAND,NPRG6800B
45,FFA6800-RF6500,NOR,APRG6800
46,SURF6800-RF6500,NOR,APRG6800B
9) Add support to Software Download for user partition download.
   The partition table in the mobile must have a attribute set
   for these partitions indicating you can download to them.
   You cannot use this feature to download to the standard
   partitions. The SD GUI has a new tab, "User Partitions" where
   you can specify the partition name and path to the data file.
   The files are downloaded in sequence from the top of the list
   to the bottom. The first file specified also determines the
   first location SD looks for the flash programmer.

4/6/07 QPST 2.7.282
1) Add option to EFS Explorer to control whether the application disables mobile sleep.
   (1) Always disable sleep (legacy behavior), (2) Never disable, (3) Disable if mobile
   responds to WCDMA status request (new default behavior).
2) For Service Programming, add MDM1000 to list of mobiles that support UMTS.
3) Add support for MSM6235, models 55, 56, 64, 70.
4) Add NV Backup support for items 4679-4794.
5) Updated RF NV Item Manager to 1.4.22.
6) Enable NV item file backup/restore from /nv/items.
7) Change model 253 back to SURF7500. Add model 47 as SURF7500a.

3/28/07 QPST 2.7.280
1) PRL Editor, changed cdma pcs channel lower limit to 0 and upper limit to 1199.
2) Update RF NV Item Manager to 1.4.21.
3) Add NV backup support for items 4432-4678.
4) Add support for FFA7500a (57), MDM1000 (88), and SURF7500a (253).
5) Add support for WinMobile to Software Download. You must use the Advanced button to enable
   download of the WinMobile image file (flash.bin). Selecting this image for download will deselect
   the Apps and Apps Header images, and enable the Apps Boot Loader and Apps Boot Loader Header
   images.

1/22/07 QPST 2.7.275
1) For dual-core MSMs, both the apps and modem processor can have a file system. Standard EFS command
   subsystem (DIAG_SUBSYS_FS) controls modem EFS on 6k and old 7k series MSMs. DIAG_SUBSYS_FS_ALTERNATE
   subsystem controls apps file system on new 7k series MSMs. For new 7k builds we want to access the
   apps filesystem. Modem file system commands not implemented, except for CEFS read. Therefore try
   Hello command with _ALTERNATE subsystem. If it works, use _ALTERNATE subsystem. Otherwise fall back
   to legacy FS subsystem ID.
2) Modify EFS free space calculation to exclude MMCs.
3) Allow QPST to connect to model numbers it doesn't recognize. This should allow QPST to connect to
   all customer phones.
4) Correct Service Programming MEID display by swapping low and high DWORDs.
5) Added models 75 (6800/ThinUI), 81 (FFA6260 NOR), 90 (SURF6260 NOR).
6) For Service Programming MIP, correct indexes for Rm and Um, was 0, 1 should be 1, 0.
   These have been wrong since the original implementation in 2003.
7) The QPST port server can accept a TCP/IP connection from a mobile. The Configuration application
   IP Server tab provides controls to enable this feature, use an IP address and port assigned by
   Winsock, or use address and port values provided by the user. The phone must act as a client and
   establish a connection to QPST. Software Download is not supported.
8) Added MSM7600 to EVDO phone models that support UMTS, and added WCDMA security to these models.
9) Fix problem with multi-image download when partition table doesn't match.
   If you proceed past the warning dialog, none of the 4 apps files get downloaded.
10) Modify Software Download CEFS to support backup/restore of legacy and alternate file systems.

1/3/07 QPST 2.7.268
1) RL Editor: Added �F?as an allowable wildcard character in the MNC field for system
   records. In the original implementation, there is a default trailing �F?when only two
   digits are used for the MNC. This �F?is not displayed. The new version retains the
   old behavior unless an �F?is used as a wildcard in which case the trailing �F?is shown.
2) Added/changed model designations:      
   Model 115, was SURF6300-BB, now FFA7600-7200 (MSM7200a)
   Model 116, was SURF6300-ZRF6000, now SURF7600-7200 (MSM7200a)
   Model 127, was FFA-ZRF6000-2, now FFA7600-7600 (MSM7600)
   Model 128, was SURF6200-UMTSG, now SURF7600-7600 (MSM7600)
3) Support NV items through 4431.
4) Add automation support for memory debug app. See mdb_saveallregions.pl sample.
5) Add deregistration retries to Service Programming Mobile IP tab.
6) Add support for Spansion WS256N MirrorBit device (aprg6500.hex).
7) Added more error checking to Memory Debug interactive application and automation interface.
8) Added support for four QSC60x5 models FFA/NOR (96), SURF/NOR (97),
   FFA/NAND (117), SURF/NAND (119).
9) Remove write-only item NV_GPSONE_PASSWORD_I from NV backup.
10) Update NV RF Item Manager to 1.4.20.

10/23/06 QPST 2.7.264
1) Update NV Item Manager to 1.4.19.
2) Fix timing problem that occasionally causes script-driven Software
   Download to abort with a 'state machine returned error' failure.

9/27/06 QPST 2.7.258
1)  Added support for NV items 4207-4392.
2)  Added MSM6280A support as models 130, 136.
3)  Add HTML file to replace FTM application. We will discontinue distributing the FTM
    application with this build.
4)  Added WLAN Editor application to installer.
5)  Update user guide to revision K.
6)  Update automation script examples.
7)  Update MSM6550 ARMPRG to add support for Spansion WS512P.
8)  PRL Editor, added band class 15: 1700/2100MHZ-AWS for cdma generic and hdr generic acquisition types.
9)  Service Programming, add "Multi-RmNet" and "Multi-RmNet + modem" selection to the
    "USB Data Device Enumeration" control in the RmNet tab.
10) Added band class 16: US2.5G for cdma generic and hdr generic acquisition types to PRL editor.
11) Software Download NV Restore, display PDP restore fail warning in yellow instead of red to emphasize
    this is a warning only.
12) Updated RF NV Item Manager to version 1.4.18.
13) Updated aprg6050 to include support for Spansion MirrorBit devices.

7/7/06 QPST 2.7.250
1) Update RF NV Manager to version 1.4.17.
2) Update NPRG6275.hex to pick up fix for 1-bit ECC errors in the spare area.
3) Added NV backup of NV_FTM_MODE_I item.
4) Adding support for models 137 (QSC60X5), 138 (QSC60X5), 140 (MSM7500), 161 (MSM7500), 169 (MSM6800 65nm).

6/6/06 QPST 2.7.249
1) Allow USB ports identified as modem ports to connect to QPST.
2) A registry setting is now available to change the maximum serial port baud rate used by QPST
   from 115.2 Kbps to a user-selected rate. Using a baud rate above 115.2 Kbps requires modifying
   AMSS code, using a special serial port card in the PC, and may require special RS-232 cabling.
   Standard PC serial ports generally do not work above 115.2 Kbps.

   Since this feature replaces the 115.2 Kbps baud rate with a user-selected rate, some
   AMSS features that always run at 115.2 Kbps (such as software download) will no longer work.

   The QPST port server reads the value from the registry when it starts and uses it in the BaudRate
   member of the DCB (look up "dcb" on msdn.microsoft.com for further information). The value you
   should use for BaudRate depends on the serial port hardware and its device driver. Some serial
   port hardware implementations use switchable frequency dividers or other baud rate encoding;
   consult the serial port user guide or manufacturer for more information on the correct encoding
   of the BaudRate value. In many cases you can use a value equal to the baud rate in bits-per-second
   (e.g. use a value of 230400 for 230.4Kbps).

   Use EXTREME caution when making this or any other registry change. Changing the wrong
   registry key may cause the Windows operating system or an application to malfunction, possibly
   resulting in a unrecoverable loss of data.

   To change the baud rate for all users edit the key:
   HKEY_LOCAL_MACHINE\Software\Qualcomm\QPST\PARAMS\PORT_SERVER

   Or, to change the baud rate for just the current user, edit:
   HKEY_CURRENT_USER\Software\Qualcomm\QPST\PARAMS\PORT_SERVER

   You will have to create the Qualcomm\QPST\PARAMS\PORT_SERVER registry keys if they don't
   currently exist. You may not have the privilege to modify HKEY_LOCAL_MACHINE.

   For either key, create a new DWORD value in the key using the name "baud_rate_" plus your
   COM port name (e.g. baud_rate_COM1 for port COM1) and set it to the encoded baud rate.

4/7/06 QPST 2.7.247
1) Update user guide to rev J. Updates gang image chapter and online help.
2) Add support for NV items 4100-4188.
3) Update nprg6500.hex with software workaround for handling 1-bit error in ECC bytes.
4) For the Software Download automation interface, correct NV restore algorithm so it will
   work with files for which you don't have write access.
5) Add support for SURF7500 NOR flash model.
6) Update MSM6550 nandprg for 1-bit software ECC workaround.
7) Update RF NV Item Manager to version 1.4.16.
8) Implement SGSN, MSC, and RRC version settings on UMTS Service Programming (System tab).
9) Add individual file backup for BREW EDT application files.
10) Add NV backup of item 1791 et. al. to MSM6100, MSM6050, 6025, 6000 phones.
11) Update QPSTConfig.mbn file in Gang Image application to correct support for MSM6280.
12) Support EFS paths up to 1024 characters. Only affects automation interface.
13) Add models 166 (SURF/FFA6550), 172 (SURF6800 65nm), 176 (SURF6255A), 177 (FFA6255A),
    180 (SURF6245), 181 (FFA6245), 182 (FFA6260), 186 (SURF6260).
14) EFS Explorer: Make the "offline" option false. Fix a bug where you still get prompted about
    resetting the phone even if you have the offline option false.
15) Add MSM6550 models to EVDO-with-GSM list.
16) Clear MRU3 with MRU2 when writing PRL.
17) In automation interface return error code to caller of SendCommand.
18) Add CAIT "define phones" feature to ban specific commands from some phone types.
    You can enable/disable feature with registry setting:
    { HKLM or HKCU } SOFTWARE\QUALCOMM\QPST\PARAMS\PORT_SERVER
    Value: a DWORD named banned_commands. Set to 0/1 to disable/enable. If value missing, feature enabled.
19) Allow QPST to connect to unknown-type USB ports.

2/8/06 QPST 2.7.240
1) Update RF NV Manager to 1.4.14.
2) Update APRG6550.HEX for Intel Strataflash support.
3) Updated EULA.
4) Update EFS error code table and EFS Explorer error messages.
5) Added support for MSM7200 SURF and FFA models.
6) Roaming list editor, relabeled wcdma band classes I, II, III,
   IV, V and VI as BC1-IMT2G, BC2-PCS1.9G, BC3-1.8G, BC4-1.7G,
   BC5-850M and  BC6-800M. Also, added new band classes BC7-2.6G,
   BC8-900M and BC9-1.7G.
7) Added support for RmNet configuration to Service Programming.
8) Service Programming, UMTS System page: Add BC5, correct coding for BC8, 9, 9P.
9) For Software Download through the Automation interface, don't download pbl.mbn file when
   trusted (secure) mode set. AMSS builds that use trusted mode won't create this file.

12/20/05 QPST 2.7.234
1) Fix problem where QPST Automation PortType occasionally gets returned as a string such as
   one of the IDispatch method names.
2) Update NPRG6250SEC.HEX, adds image hash support, fixes endpoint toggle bit, uses new flash
   driver that ignores OP_RESULT bit for read status check.
3) Phone memory debug app: when saving memory regions the application now displays all files that
   will be overwritten, and asks for user's authorization to overwrite, up front instead of asking
   for authorization on each file individually during the save.
4) If the phone returns an error during directory iteration, make sure to close the file handle.
   Otherwise you can't do any further file operations on the phone.
5) Add MSM6280 to list of MSMs that use a PBL.
6) Add option to persist server settings to a file, QPST_Server.ini. This works around the problem
   where some users don't have access to the HKLM registry key. Will save port configuration and
   autoshutdown flag. Use registry setting that specifies the folder for the ini file to enable this
   feature (QPST bin folder in this example):
Windows Registry Editor Version 5.00
	
[HKEY_LOCAL_MACHINE\SOFTWARE\Qualcomm\QPST\2.0\Server]
"Server_INI_Files"="c:\\program files\\qpst\\bin\\"
  All users must have read/write/enumerate access to this directory.
7) In PRL Editor, change the mask on UMTSGeneric and UMTSPrefGeneric Band cells to accept 5 digits
   instead of 4.
8) Modify serial port code to not open NMEA, Data, or Unknown type ports. Opening an NMEA port can cause
   QPST to freeze. On USB port restart insure port still compatible. User could have swapped in a phone
   that maps NMEA to this port.
9) Fix multiple problems in Configuration Add Port that caused the display of the wrong port when you
    selected one from the list.
10) DmProxyWin modified to accept two-digit COM port numbers.
11) Added NV items 3640-4099 to NV backup and QCNView.
12) Remove code that retries EFS2 commands that return bad status or timeout. Now will only get the
    low-level QPST server retry on timeout.
13) Update FTM application to 6.10.0.
14) Update RF NV Item Manager to 1.4.10.
15) Increase armprg size from 64k to 256k for MSM7500 Software Download.
16) Don't download PBL when trusted (secure) mode set - AMSS build won't include a PBL file.
17) Include apps files for MSM7500 Software Download.

11/2/05 QPST 2.7.228
1) Modified Phone Memory Debug App file dialog to support new dialog style.
2) Added items 3634-3639, 885-888, CDMA NV items (item 10 et. al. - UMTS phones), to NV Backup.
3) Added support for MediaFLO phone.
4) Updated RF NV Manager to 1.4.8.
5) RLEditor: added support in acquisition record for CDMA generic and HDR generic Band Class 14.
6) Added total progress indicator to Software Download.
7) For multi-image download, query user for partition override if required. Remove checkbox option.
8) In Software Download, send a Close after Hello so that if the user tries a download after a QPST crash (phone already in streaming download mode) the previous download attempt gets terminated.
9) Add image hash code comparison to Software Download. If the hash code of the file matches the hash code of the partition in the phone, skip the download of the image.
10) Change 4GV narrowband service option from 0x8027 to 0x44 in Service Programming.
11) Add new gang image application, remove old one. User Guide and online help not updated yet.

10/12/05 QPST 2.7.225
1) Software Download will now look in the phone image directory first to find the nprg/aprg flash
programmer file. For multi-image download, it will use the modem image directory. IF not found it
will fall back to the version distributed with QPST.
2) Added NV items 3520-3633 to Software Download NV Backup.
3) Added six MSM6280 models.
4) Added two SQSC60x0 models.
5) Add backup of NV items 441, 946, to MSM6250 and MSM6275.
6) Add backup of factory NV items to all phones.
7) Add Phone Memory Debug App to QPST.

8/15/05 QPST 2.7.222
1) Added GetCOMPortList() to Automation server IAtmnServer interface.
   Returns list of available COM ports. See get_com_port_list.pl.
2) Update Config App Add Port dialog to filter ports based on diag/non-diag type.
3) Modify Remove Port to shut the port down and remove it from the QPST configuration immediately.
4) Update Automation interface to support Add/Remove port. See add_remove.pl.
5) NPRG7500.HEX : Use new flash drivers with MPU support.
6) Added NV items 3467-3519.
7) NPRG6250SEC.HEX : Erase failure of OTP block is skipped.
8) Add Get/Set EnablePort boolean property to IAtmnServer Automation interface. See enab_disab.pl.
9) Modify IAtmnServer Automation interface method GetPort to accept either a port name or a port ID
   for its parameter.
10) Correct problem in QPST server where a delayed response sent by DIAG_SUBSYS_CMD_VER_2_F could
    overwrite the initial response from the command.
11) Move Software Download Partition Override checkbox from MultiImage/OBL tab to Advanced dialog.
12) CEFS download will now work for a mobile already in download mode (you must choose the correct
    downloader in the Software Download Settings dialog).
13) Correct problem with EFS Explorer that prevented it from creating a zero-length file.

8/1/05 QPST 2.7.218
1) Added NV items 3384-3466.
2) NPRG6275.hex & NPRG6800.hex - added watchdog kicks to prevent reset while waiting for USB in-token.
3) APRG6275.hex & APRG6800.hex - added Spansion MLC NOR support.
4) Use shared read mode when opening MBN file for software download.
5) Display capture application modified to use the delayed response command if supported by the
   phone build.
6) FTM application updated to version 6.8.0.
7) RF NV item manager updated to version 1.4.6.

7/14/05 QPST 2.7.215
1) Fixed various problems with Software Download automation functions.
2) NPRG6250SEC.HEX : Add support for preservation of SIM Secure data.
3) FTM application version 6.7.0, RF NV Item Manager version 1.4.5.
4) Increase software download multi-image Open timeout from 3 to 10 seconds.
5) Added O_TRUNC to EFS2 write open, and set mode to 0666. Set read mode to 0444.
6) Change interpretation of EFS2 file time to Unix time epoch.

6/24/05 QPST 2.7.213
1) APRG6275/NPRG6275 - support added for Spansion MLC NOR.
2) NPRG7500 - USB support fixed.

6/9/05 QPST 2.7.212
1) For multi-image Software Download, if the user has enabled partition override and
NV backup/restore, always restore NV. Partition override erases flash including
NV, but the phone may still report the NV version it did with the previous
AMSS build. Software Download doesn't normally restore NV unless the new AMSS
build has a different version number then the previous build.
2) For MSM7500 and later, don't download the PBL file during Software Download.
3) Add AppVersion property to the root QPST Automation interface (IAtmnServer).
4) Update NPRG7500.hex to version 11.00.01 (Incorporates NAND ECC workaround, SMI support).
5) Software Download - partition file always required (removed checkbox).

6/3/05 QPST 2.7.210
1) Added two NV item groups (band pref and Bluetooth) to some MSM6250 models.
2) Add CEFS download to Software Download application. A CEFS file represents
a snapshot of the embedded file system. The download will replace the existing
file system with the contents of the CEFS file.

5/31/05 QPST 2.7.209
1) Updated NV RF Item Manager to 1.4.4.
2) Removed NV item 2824 from Software Download NV Backup.
3) Remove un-writable NV item NV_DIAG_SPC_UNLOCK_TTL_I from NV backup.
4) Updated NV Decoder.qdf file (RF NV Item Manager) with new WCDMA NV items.
5) Updated NPRG6250.hex:
   Correct handling of MIBIB when only one present
   Do not copy forward Progressive Boot page while programming AMSS
   Correct handling of OEMSBL swapping
6) Updated aprg/nprg for 6275 & 6800:
   Fix single MIBIB case on NAND - both MSMs
   Fix OEMSBL swapping on NAND - both MSMs
   Change NOR link address to match current builds dloadarm.c
   for 6800 only.  This will not be compatible with
   older builds, but is required for current builds.
7) Updated NPRG6550PB.hex, limits ELF segments in BIB to 16.
8) Check in first nprg7500.hex version.

4/29/05 QPST 2.7.206
1) Added support to Software Download and Automation interface for
download of application boot loader and boot loader header file.
2) Added preliminary MSM7500 download support.
3) Added NV items 3363-3383.
4) Added FFA6100-ZRF6155 and SURF6100-ZRF6155.

4/28/05 QPST 2.7.202
1) Added NV items 3245-3362.
2) Added MultiImageDownload and OTPImageDownload to IQSoftwareDownload
Automation interface. Added sample Perl scripts mi_dwnld_gui.pl and
obl_dwnld_gui.pl.
3) Updated FTM application to 6.6.0 and RF Item Manager to 1.4.3.
4) Added apps image download to Software Download.
5) Fix problem where QPST server occasionally would consume 100% CPU time.

4/18/05 QPST 2.7.200
1) Update nprg6800.hex to 09.00.02.
2) Fix NOR download to 16 Mbyte flash (> 255 blocks).
3) Added aprg6800.hex version 09.00.03.
4) Added EVRC service options for 4th generation voice (4GV) narrow- and wide-band.
5) Updated definitions of Dynamic Feature item command constants (subsystem 30) to
match new command set. Old command 6 had already been defined.
6) Added NV items 2985-3244 from MSM6500_NV.00.00.47.
7) FTM application updated to version 6.5.0.
8) RF NV Item Manager updated to version 1.4.2.
9) Changes to Service Programming:
"Data" tab:
 Set NV_DS_INCOMING_DATA_RLP_TIMEOUT from_I "Reduced Dormancy Timeout (ms)".
 Set NV_DS_DEFAULT_INACTIVITY_RESTORE_TIMEOUT_I from "Resume Default Dormancy Timeout (ms)"
 "PPP Config" tab:
 Set NV_DS_SIP_RM_NAI_I from "Tethered NAI" (Um only).
 "M.IP" tab:
 Set NV_DS_MIP_RM_NAI_I from "tethered nai".
10) Use 5 min timeout on partition command.
11) New NPRG6250SEC.hex version:
Erase chip with partition table override flash set without checking for partition table in NAND
Support Single Image to Multi-Image upgrade by using partition table override flag
Support download of Compact EFS2 image
Support download of FOTA UI binary image
Fixes placement of FOTA UI block and uses latest flash drivers.
12) New NPRG6250.hex version:
This downloader supports the erase flash command just added to the protocol.  It will be used
to downgrade multi-image boot builds to single image boot builds.
13) Add support to Software Download UI for flash erase. Set flash erase timeout to 2:00 minutes.
14) Increase restart timeout to 4:00 minutes to allow EFS rebuild after a flash erase.
15) Compact EFS download support added to Automation interface.
16) Modified USB monitor thread to correct phone reset detection problem.

3/14/05 QPST 2.7.193
1) Add online help to BuildGangImage. Show version on title bar.
2) Update user guide to add chapter for BuildGangImage.
3) First release of FFA6250 One-Time Programmable (OTP) Multi-image Secure Boot.
4) First release of SURF6255 support.
5) Support new item-based dynamic features.
6) Always enable PRL on UMTS UEs.
7) For multi-image download, take care of case where mobile is already in download mode.
8) Modify for updated MSM6550 NANDPRGS. Now have one NANDPRG for both 8- and 16-bit flash,
and one progressive boot nandprg for 8- and 16-bit flash.
9) Modify IQSoftwareDownload::RestoreNV Automation interface to accept a third argument,
allowESNMismatch. Set to 0 for normal restore, 1 to restore even if ESN in restore file
doesn't match ESN in phone. You must modify any Perl script that calls RestoreNV or you
will get a Win32::OLE(0.1005) error 0x8002000e: "Invalid number of parameters" error.
10) Updated aprg6275.hex and nprg6275.hex.

1/12/05 QPST 2.7.183
1) Added a "Port Shutdown" item to the Configuration application Port tab right-click
menu. Use this menu item to configure the server to send a reconfiguration command to
the phone when QPST shuts down. You can either send a command to switch the phone
back to data services mode, or a command to tell the phone to release the current port
and begin scanning all ports for activity (requires FEATURE_DIAG_MULTI_PORTS).
2) Enable Automation server GUI on the reset.pl sample Perl script.
3) Added Version "get" property ($portlist->Version) to the port list Automation
interface ($qpst->GetPortList()) to retrieve QPST build version.
4) Add models 230-232, 238-240, 248-250.
5) Modify loop initialization for Build Gang Image code that retrieves factory data.
6) Change PRL Editor to allow odd numbered channels for 2GHz band.
7) Update NV definitions to items 2742-2827.
8) If EFS Explorer tries to iterate a directory and the phone returns an error, change
the directory's icon to 'prohibited' rather than raising an error dialog.
9) Updated nprg6275.hex to 09.00.02.
10) Added aprg6275.hex and support for MSM6275 NOR flash download (mbn binary file type).
11) Updated FTM application to 6.4.1a.
12) Updated RF NV Manager application to 1.4.1.
13) Added support for FFA6550-EZRF6500 (8-bit NAND).
14) Update NPRG6800.hex.
15) Software Download Multi-image: Append a trailing "\" for the case where someone 
uses the Advanced option but doesn't terminate the path correctly.

1/7/05 QPST 2.7.175
1) Update file combo control to properly handle directory drag/drop.
2) Modify Software Download boot loader combo box to display a longer history list.
3) Flash Gang Image build application extensively modified per new requirements.

12/16/04 QPST 2.7.174
1) Update RF_NV_Manager to 1.4.0
2) Update FTM_EVAL_GUI to 6.4.0.

12/1/04 QPST 2.7.172
1) Disable model compatibility test for PBN file.
2) Update NPRG6550PB_16.hex to FLASHPRG_MSM6550.08.00.01.
3) Added support for MSM6275 multi-image download to Software Download
application.

11/12/04 QPST 2.7.167
1) Added support for progressive boot (PBN) files to Software Download.
2) USB ports occasionally send the disconnect/reconnect events in reverse
sequence during a mobile reset. This would cause QPST to lose the mobile when
it was reset. Added code to restart port if disconnect event handler discovers
port has already reconnected.
3) Remove hardware flow control / mobile detection menu for UART ports that
was introduced in 2.7.124.
4) Added NV items 1992-2506.
5) Add missing MSM6500 JIZRF models to NV backup.
6) Fix overwrite of write-only items NV_DS_MIP_SS_USER_PROF_I and
NV_DS_MIP_DMU_MN_AUTH_I in Service Programming when you do a read followed
by a write.

10/19/04 QPST 2.7.165
1) Added progressive boot support for MSM6550.
2) Fix bug in Automation interface. The phone enumeration stopped with
no phones listed if COM1 didn't have a phone attached.
3) Updated MSM6550 NANDPRG to FLASHPRG_NANDFLASH.08.00.00.
4) Fixed bug in Software Download automation that prevented second
download from succeeding.
5) Added DownloadPhoneAndBootImage method and NANDFlash property to
Automation interface.

9/29/04 QPST 2.7.162
1) Add MEID display to Service Programming status pane.
2) Move Require PW encryption from Sevice Programming IPv6 to the PPP tab.
Move IID field from the data tab to the IPv6 tab.  
Reordered IPv6 failover combo box items.
3) Renamed SURF6250-GWZRF6250 to FFA6250-GWZRF6250.
4) Updated MSM6700 ARMPRG.
5) Update dynamic features to version 2. Adds rel_d_neg_sci_supported.
6) Added QPSTAtmn Provisioning interface to allow scripts to get and set
nv items and roaming lists. Added sample VBScript and updated Automation
readme.
7) Added RLEditor support for new generic CDMA/HDR band classes 8-12 and
retitled some existing band classes to be clearer.
8) Update ARMPRGs to FLASHPRG_MSM6550.07.00.02.
9) Added RLEditor support for Concatenated PRL files. Added wizards for
splitting and joining, added autodetection on open, and added code to
perform validation and split/join operations. Also changed command line
processing to simply open a file if a path is the only command line param.
10) Added backup NV item NV_SMS_I.
11) Added NV items 1945-1991.
12) Software Download and Service Programming no longer attempt to read
write-only password NV items. The phone returns DIAG_BAD_PARM_F for these
items.
13) Updated FTM application to 6.3.0 and RF NV Item Manager to 1.3.1.

8/23/04 QPST 2.7.154
1) Before writing an EFS file test the target filesystem for free space. Previous
versions always test the root filesystem for free space. For this to work the mobile
must support reporting per-filesystem fress space.
2) Add NV items 1891-1944 to Software Download NV backup.
3) Correct conversion of IPv6 IID value when bit 31 == 1.
4) RL editor fix: conversion from text to binary for IS-683C or D did not properly
set the SSPR REV.
5) Software Download will now warn if you don't download a boot image along with
a phone image for NAND flash mobiles, or if you try to download a boot image to
a NOR flash mobile.
6) Added IPv6 provisioning to Service Programming.
7) Limit amount of data QPST port server will buffer while looking for an HDLC end
character. Previously if a user connected a non-phone to a COM port and
the device sent data to the port, QPST would buffer received data until it
exhausted virtual memory.
Set with key {HKLM or HKCU}\SOFTWARE\QUALCOMM\QPST\PARAMS\PORT_SERVER\read_limit_COMx
DWORD range [4096, MAX_DWORD], default 8192.
8) Optimize port server memory use for serial vs. USB and short message fragments.
9) Updated Automation interface: added Software Download interface, made bug fixes,
changed some script names, updated Automation readme file.

7/22/04 QPST 2.7.152
1) Updated Dynamic Features to version 1 (adds sync_id_supported, reconnect_msg_supported).
2) Added point-to-point SMS support to MSM6500 Service Programming.
3) Added preliminary MSM6700 support.
4) Add QPST Automation server and preliminary release of sample files.
enumerate.pl - enumerates active mobiles and shows their state.
offline.pl - sets a mobile offline.
reset.pl - resets a mobile.
spc.pl - unlocks a mobile by sending the Service Provisioning Code.
getinfo.vbs - similar to enumerate.pl.
sendcommand.vbs - sends an NV read command of MIN1 to the mobile.

6/28/04 QPST 2.7.147
1) Added preliminary Download and Service Programming support for MSM6550.
2) Updated MSM6550 armprgs to FLASHPRG_MSM6550.07.00.01.
3) Modify polling on USB port to skip baud rate changes. Baud rate changes
have no effect on USB, but do cause the mobile to reset log, debug message,
and event masks.
4) Modify receive loop to queue multiple receive buffers to the device driver.
5) Updated FTM application to 6.2.1.
6) Updated RF NV Manager application to 1.3.0.
7) Updated QPST User Guide & help files to revision F.
8) Display list of unused ports in Configuration Application Add New Port dialog.
List entry also describes port type (serial, USB diagnostic, USB data modem).
User can click on a row in the list control to fill in the port name and label
fields.
9) Add NAS and SMS-CB to MSM6500 Service Programming.

5/28/04 QPST 2.7.141
1) Added support for IPv6 NV items to Service Programming.
2) Updated COM port code to improve receive throughput.
3) Add model 198 to download as NAND.
4) Added NV items 1801-1891 to NV Backup.
5) Updated RF NV Item Manager to 1.2.2.
6) Updated FTM application to 6.1.2.
7) Modified NV Restore to work with read-only QCN files.

4/22/04 QPST 2.7.138
1) Add backup/restore of PDP Context files to Software Download.
2) Updated armprgs:
   aprg6100.hex, nprg6100.hex to FLASHPRG_MSM6100.06.05.00.
   aprg6250.hex, nprg6250.hex to FLASHPRG_MSM6250.06.05.00.
   aprg6500.hex, nprg6500.hex to FLASHPRG_MSM6500.06.05.00.
3) Add NV items 1312-1800.
4) QCNView rewritten, adding a tree control as the default data presentation. This
was a prerequisite to adding display of PDP Context file contents. The application
still supports the original text view.
5) Updated RF NV Item Manager to release 1.2.0. Minor changes, primarily removing
obsolete NV items.
6) Modified EFS Explorer to disable mobile sleep when it connects to a phone,
restore original sleep state when disconnecting. This should improve performance
of this application on mobiles that use long REX ticks when sleeping.
7) Code optimization to reduce QPST CPU usage when connected to a busy
mobile over a slow (RS-232) datalink.
8) Update FTM application to 6.1.1.
9) Updates to FTM and RFIM help files. Added QCNView help files.
Updated QPST User's Guide to rev D.
10) Add model 199.

1/14/04 QPST 2.7.132
1) Added FTM and RFIM help groups to installer.
2) Increased maximum image size to 64 meg to prevent the Gang Flash Image application
from crashing on large images.
3) Send close command to armprg on download abort.
4) Fixed a race condition that caused the download component to crash when
the download was aborted.
5) Software Download warning dialog about hex file / phone model number mismatch now
displays both model numbers.
6) Added support for DIAG_SUBSYS_CMD_VER_2_F (delayed response and status).
7) Updated APRG6100FFA.hex to support USB (FLASHPRG_MSM6100NORFFA.06.03.00).
8) Changed model 184 from 6250 SURF to 6100 FFA.

12/17/03 QPST 2.7.129
1) Add NV items 1196-1311.
2) Update FTM and RF NV Manager applications.
3) Add support to Service Programming for NV_PPP_CONFIG_DATA_I. This will show
up as the IP Config tab. Usernames, passwords, and DNS server addresses have also been
moved to this tab.
4) Service Programming, changed "Dynamic Features" tab to "IS-2000 Dynamic Features".
5) Deleted obsolete help files, updated QPST user guide and help, added NV item manager
and FTM help.
6) RF NV Item Manager, update the GSM Temp vs Comp NV items.

12/2/03 QPST 2.7.127
1) Added serial port hardware control line monitor. You can use this on
some mobiles in place of polling to detect the presence of a mobile.
Use the Configuration Application Ports tab, right click on the port and
select Port Control. You can configure the port to use standard polling,
use DSR or CD (RLSD) lines to detect a mobile, or use a combination of both.
NOT ALL MOBILES SUPPORT HARDWARE CONTROL LINES. Some have them hardwired
active, which will prevent QPST from detecting when the mobile resets.
Not applicable to USB ports.
2) Updated armprgs:
Incorporate new flash driver changes to fix bug in Samsung K9F1208 driver
aprg6100.hex, nprg6100.hex to FLASHPRG_MSM6100.06.03.00
aprg6500.hex, nprg6500.hex to FLASHPRG_MSM6500.06.03.00
APRG6250.HEX, NPRG6250.HEX to FLASHPRG_MSM6250.06.04.00 (USB enabled).
3) Modified SCRAMP and Software Download to use demand paged memory rather
than statically allocated memory. Set maximum image size to 64 meg.
4) Fix problem with misidentifying 3rd party serial port card as USB.
5) Modified QPST Configuration Start Client to set working directory to client
directory.
6) Change test for USB device driver name to case-insensitive for compatibility
with USB 2.x drivers.
7) Add write timeout when using a USB device. Otherwise, if phone connected
by USB cable but SIO set to UART, writes to phone never signal completion,
causing the write thread to block.
8) Insert delay after opening USB phone port. Sometimes don't see phone
responses and QPST shows no phone on port.
9) Preliminary support for WinCE bin format software download.
10) Updated FTM to FTM_EVAL_GUI_6.1.0.
11) Updated RF NV Item Manager to RF_NV_Manager_1.1.0.
12) PRL Editor: Added support for new roaming list system record format with
the title, "PRL Simplification for International Roaming". It allows a normal
1x record to substitute an MCC/IMSI_11_12 for the SID/NID fields in any
supported file format. Relaxed constraints on accepting previously existing
1x-MCC system records. Fixed bug where all fields except
SID/NID/NID_INCL/MCC/IMSI_11_12 for an existing 1x-MCC record were reset.

10/31/03 QPST 2.7.123
1) Added PRL support to MSM6200, MSM6250 Service Programming.
2) Disable mobile sleep when reading NV items in Service Programming.
3) Enabled Offline ESN feature in Software Download. Mobiles that
have R-UIM hardware do not always return the correct ESN to the status
command. This feature sets the mobile offline, then uses the value in
the ESN NV item as the seed for the NV backup file name. To enable the
feature set the Options... Settings... "Use offline mode ESN" checkbox.
4) Added the Display Capture application to QPST.
5) Replaced the RF Cal Editor application with the RF NV Item Manager
application.
6) Poll for download mode a second time if we receive a NAK the first
time. This helps situations where a poll for data mode causes the mobile
to NAK the next diag mode command.
7) Add NV items 1033-1195 to NV backup.
8) Add download support for MSM6100 NOR-flash FFA.
9) Add models 192-197.
10) Updated MSM6500 armprgs to FLASHPRG_MSM6500.06.01.00.
11) Updated PRL editor:
 - Changes to match latest IS-683D spec related to PLMN system field. Minor
 bug fixes.
 - Full support for IS-683D multi-LAC PLMN system records.
 - Fixed bug with new PLMN multi-LAC size calc, made user interface consistent
 with [new] documentation.

9/26/03 QPST 2.7.118
1) Added NV items 1019 - 1032.
2) Added dynamic feature menu item to more mobiles.
3) Modified DF dialog to allow (none) fwd/rev rates.
4) Changes to PRL Editor:
 -Properly handle the IS-683D SSPR_P_REV field in all cases and the QC header that
 is present in some non-RLEditor IS-683A and C files.
 -Changed previous SSPR_P_REV fix to apply to both C and D formats, and to automatically
 fix files that were saved with the wrong value. Open files in lowest applicable format
 rather than highest.
5) Change to DMProxyWin:
 -Disable QPST "auto server shutdown" feature during startup of DMProxyWin as the feature
 will cause problem when DMProxyWin needs to disconnect/reconnect to QPST server at high frequency.
6) Changes to BuildGangImage:
 -Set "Include ECC Data" checked by default.
 -Don't require boot and phone image file names if just building EFS contents.
7) Increased SCRAMP image size from 8192K to 12288K, released as version 1.91.
8) Changes to BuildGangImage - factory image dump preparation added.
9) Increased Software Download image size from 8192K to 12288K.
10) Enabled boot loader download in Software Download application.
11) Updated ARMPRGS:

aprg6100.hex, nprg6100.hex to version 06.00.00

Support for new Streaming Download Protocol.
Support for boot loader download to NAND flash.
Uses NAND device drivers from DMSS EFS2.
Supports new AMD AM29BDS128H 16MB Flash.

==================================================================

aprg6250.hex, nprg6250.hex to version 06.00.00

Support for new Streaming Download Protocol.
Support for boot loader download to NAND flash.
USB support added but temporarily compiled out
        waiting for USB support in DMSS.
Completely new NOR flash programming layer.
Supports new AMD AM29BDS128H 16MB Flash.
Uses NAND device drivers from DMSS EFS2.

==================================================================

aprg6500.hex, nprg6500.hex to version 06.00.00

Support for new Streaming Download Protocol
Support for boot loader download to NAND flash.
USB support added but temporarily compiled out
        waiting for USB support in DMSS.
Completely new NOR flash programming layer.
Supports new AMD AM29BDS128H 16MB Flash.
Uses NAND device drivers from DMSS EFS2.

12) Distributing version 6.0.1 of FTM application.


8/25/03 QPST 2.7.114
1) Added UMTS SMS-CB support.
2) Insure delay if mobile returns a zero-length response.
3) Removed references to warmprg.hex and aprg6200_260.hex from Software Download.
4) Logs port bytes to debug file with trace level 2.
5) Added NV items 934-1018.
6) Change NV_SMS_BC_SRV_LABEL_SIZE from 10 to 30.
7) Updated aprg6200 to 04.50.00. This supports writing both MSM6200 flash devices.
   You must use SCRAMP 1.90 (included in this distribution) to create dual flash hex files.
8) PRL editor: Fixed bug with IS-856 system records where the subnet id field was written to the
   file incorrectly. Fixed another bug with HDR subnetid parsing. Split PLMN field into MNC and MCC
   fields. Added special parsing, reading, writing and validation for the new fields. Fixed some
   minor problems with unprinting generic acq records.
9) Software Download: Turn off sleep before doing an NV backup, then restore settings when done.
10) If polling loop detects a WCDMA mobile, use longer timeouts.
11) Log thread shutdown data with timestamps.
12) Use full date/time format in server debug file.
13) Use registry entries to set polling thread parameters, otherwise use defaults.
    Looks in two places:
    first - HKEY_LOCAL_MACHINE\SOFTWARE\Qualcomm\QPST\params\port_server
    finally - HKEY_CURRENT_USER\Software\Qualcomm\QPST\params\port_server
    Looks for DWORDs in this range (all times in mS):
    polling_timer_interval_ms [600, 2000]
    polling_max_tries [3, 10]
    polling_timeout_ms [400, 3000]
14) Modify Scramp to support one or two flash devices (1.90).
15) Modify Software Download to support one or two flash devices.
16) Modified M.IP to use 3-state checkboxs that render the undefine state as a
    gray square instead of a disabled checkmark.

7/15/03 QPST 2.7.108
1) Updated aprg6100.hex to 05.08.00.
2) BuildGangImage: Includes modifiaction to allow either only Factory Image
   or EFS2 Data file to be created. Fixed bug related to file creation date.
3) PRL Editor: Fixed minor validation bugs and cleaned up print/unprint of system records.

7/11/03 QPST 2.7.107
1) Changes to RL Editor:
   Added support for new "undefined" acq and sys types. Deleted defunct nonstandard (pre-A) format
   files (had already removed them from the project).
   Fixed bug in size calculation for type-specific part of new special system record.
   Rearranged system table to put all shared columns first and to minimize type-specific columns.
   Added support for dynamically updating column titles, so titles correspond to the currently
   selected row.
2) Corrected BuildGangImage output file name validation.
3) Added MSM6025 models.
4) Fixed Dynamic Feature bit alignment problems with NV_DF_I item write.
5) Added MSM6250 support to Software Download and Service Programming for new model numbers.
6) Corrected MIP HA interpretation for MSM5500.
7) Update BuildGangImage to provide radio button options describing which files to produce.
8) Updated MSM6250 APRG and NPRG to 05.01.00.
9) Added support for Dynamic Features.
10) Based armprg nand/nor protocol decision on mobile model number, not "nprg" file name prefix.
11) Updated aprg6500 and added NPRG6500 to 05.01.00.

6/26/03 QPST 2.7.104
1) Added support to Service Programmign for NV_PKT_DIAL_STRINGS_I
2) Add file drag support to EFS Explorer.
3) Added three missing MSM6500 model numbers to service prog agent.
4) Code changes for dynamic features, Phone... menu disabled for now.
5) Modified BuildGangImage to always produce both output files.
6) Updated APRG6500.hex to 05.01.00.
7) Packet dial string, limit character set to 0-9, *, #. Limit length to 15 characters.
8) Remove UMTS Data tab (mobile now uses a configuration file), move user/password from Security
   to Data.
9) Added support for NV items 924-932.
10) Added BuildGangImage application to installer.

6/12/03 QPST 2.7.100
1) Missing GSM preferred mode, DCS, E-GSM, P-GSM bands from Leopard.
2) Added new models to SD 2.0 and HDR determination code tables.
3) Added support for models 147-181: 
   -Full support for new MSM6000 models, 
   -Download support for MSM6250, MSM6500.
4) Updated aprg6200.hex to 04.16.00.
5) Bug fixes to PRL editor.
6) Updated aprg6100.hex and nprg6100.hex to 05.07.00.
7) Updated PRL editor to support IS-683D.
8) Changed directory name comparison used in EFS Explorer directory create to case sensitive.
9) Implemented file history lists in Software Download for image, backup, and restore file names.
   The controls also accept dragged files now.
10) Fixed Software Download file name problem that would occur if you double-clicked a filename that
    contained a space. Only the last part of the filename ended up in the edit control.
11) Added NV items 919-923.
12) Removed extra trailing blanks from some NV item names in the list used by QCNView.
13) Increased timeout to handle slow file deletion with full EFS2 file system.
14) Added IS-683B to PRL editor, and restructured project.
15) Updated armprgs:
    armprg.hex : 03.15.00
    aprg6000.hex : 04.12.00
    aprg6050.hex : 04.16.00
    aprg6100.hex & nprg6100.hex : 05.06.00
    aprg6200.hex (replaces aprg6200_192.hex) : 04.15.00
16) Modified EFS2 packet sizes for increased efficiency.
17) Service Programming will now display a dialog listing any NV items that failed to write.
18) Phonebook component no longer returns an error if NV returns a read-only status to a write.
19) For MSM6300, after NV write completes Service Programming app scans NV error list and
    modifies phonebook and security display to flag any un-written entries with a red w-slash
    state icon.
20) Command line version of RLEditor unprint:
    RLEditor.exe -u sourcefile.txt destfile.rl
    to unprint sourcefile.txt and store the result in destfile.rl.
21) Added NV items 911-917.
22) Updated aprg6100.hex and nprg6100.hex to 05.05.00.
23) Remove "GSM on 1x" option from RTRE combo box.
24) Updated aprg6000.hex to 04.11.00.

3/19/03 QPST 2.7.91
IF YOU USE NAND FLASH YOU MUST UPGRADE THE SURF/FFA BOOT CODE BEFORE ATTEMPTING TO
USE THIS VERSION OF QPST.

1) Added support for 32-bit DMSS DLOAD command. QPST will choose to use the 32-bit write
   command when it detects protocol version 5 or higher.
2) Added support for sending blocks to NANDPRG in ascending order. QPST will use this order
   when the parameter request feature field indicates NANDPRG supports NAND_DL.
3) Updated NANDPRG to 05.04.00.
   -Support for new spanless boot loader method.
   -This NPRG6100.HEX must not be used with old boot loaders.
4) EFS Explorer can now display a progress bar during file transfer.
   Use "View... File Xfer Animation" to enable/disable the old file
   transfer animation, and "View... File Xfer Progress Bar" to enable/disable
   the new progress bar. You can enable either, both, or neither. By default
   you will get both.
5) The roaming list editor can now read an input file and generate a PRL.
6) Debug logging modifications:
   -Perform logging in separate thread so disk latency doesn't slow QPST server.
   -Log sync and async response times from mobile.

3/3/03 QPST 2.7.89
1) EFS Explorer modified for EFS 2.0 compatibility.
2) EFS Explorer modified to perform file transfers in a separate thread, to avoid
   "Server Busy" warning.
3) Updated nprg6100.hex to 00.01.03, has fix for flash devices with
   bad blocks.
4) Modified Service Programming Mobile IP to use reserved values for
   dynamic and unset based on mobile model.

2/11/03 QPST 2.7.87
1) Added NV item 910.
2) Modified Service Programming Security to write PPP user/password.
3) Updated armprg.hex to 03.14.00 for MSM5100/1505.
4) Added NV items 907-909.
5) Added model numbers 142-146.
6) Updated model names for models 120-123.
7) Updated model names for models 118, 119.
8) Retry EFS file space queries.
9) Fix DMProxyWin scroll.
10) Make DMProxyWin settings persistant.
11) In QPST Server, send the DIAG_RPC_F command but don't wait for a mobile reply.
    The caller must implement acknowledgement testing. Only affects Send() not
    SendSync(). Also treat DIAG_RPC_F like a streaming response (like logs, events,
    etc).
12) Changed NV Backup and Restore: if phone ESN changes, application updates NV
    file name with new ESN. When Backup or Restore tab first selected, applicaion
    sets NV file name based on ESN. If tab changed while phone unavailable, file
    name will update when phone becomes available, even if ESN hasn't changed.
    Note that an ESN of all 0's is still a special case - version numbers not
    incremented for this ESN.
13) Added support for NV items 903-905.
14) Service Programming: always enable SD 2.0 for MSM6000 and MSM6050.
15) Service Programming: always disable SD 2.0 HDR mode for MSM6000 and MSM6050.
16) Updated to armprg 3.2 for byte stuffing.
17) Various changes to support EFS 2.0 through the EFS Explorer.
18) Updated EFS COM component for EFS2 diag protocol support.
19) Updated installer and project to distribute DMProxyWin application.

Copyright (c) 2000-2017, QUALCOMM Incorporated
All rights reserved.
