use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

# Show (1) the $prod_id GUI or hide (0) it?
$show_gui = 0;

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

# Show the Automation server GUI. Off by default.
if ($show_gui)
{
  $qpst->ShowWindow();

  print "Select a mobile on the GUI and press enter to continue...";
  <STDIN>;
}

###############################################################################
#
# First remove all ports assigned to QPST, then add back just active USB ports.
#
###############################################################################

if (defined $qpst)
{
  $port_list = $qpst->GetCOMPortList();
  $port_count = $port_list->PortCount;

  for ($i = 0 ; $i < $port_count ; ++$i)
  {
    $port_name = $port_list->PortName($i);
    $port_type = $port_list->PortType($i);
    $assigned = $port_list->AssignedToQPST($i);

    print "\n";
    print "port name   [$i] : $port_name\n";
    print "port type   [$i] : $port_type\n";
    print "assigned    [$i] : $assigned\n";

	# Remove all assigned ports
	if ($assigned)
	{
	  print "Removing port $port_name\n";
	  $qpst->RemovePort($port_name);
	}
  }

  # Release the component.
  undef $port_list;

  # Refresh the port list.
  $port_list = $qpst->GetCOMPortList();
  $port_count = $port_list->PortCount;

  for ($i = 0 ; $i < $port_count ; ++$i)
  {
    $port_name = $port_list->PortName($i);
    $port_type = $port_list->PortType($i);

    # Add all USB ports back.
	  if ($port_type eq "USB/QC Diagnostic")
	  {
	    print "Adding port $port_name\n";

	    #                    name,      label
	    $qpst->AddPort($port_name, $port_name);
	  }
  }

  # Release the component.
  undef $port_list;
}

if ($show_gui)
{
  print "Press enter to exit script";
  <STDIN>;
}

# Release the automation server.
undef $qpst;

print "Done!\n";