package efs_error;

use strict;
use Exporter;
use Win32::OLE::Variant;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);
@EXPORT = qw(print_error);

sub print_error
{
  my ($error, $efs_obj) = @_;

#
# EFS commands sent to the phone return a "errnum" value to indicate command
# success or failure. An errnum of 0 indicates success.
# The code returned as the third parameter of GetLastError returns the
# errnum if the phone rejected the command. Error codes 1 through 512
# represent phone errnum values 0 through 511. Error code 513 indicates an
# errnum > 511.
# The list of errnum values has been updated for the newest phone builds.
#
# Error codes > 513 represent QPST internally detected errors.
# EFS directories protected by the phone will return EFS_bad_cmd_response
# because the phone's diagnostic interface rejects the command.
#
# An HRESULT of 0x80042190 indicates QPST performed a normal error recovery.
# An HRESULT of 0x80042191 indicates an unexpected QPST error.
# Because QPST calls Microsoft functions that also return HRESULTs, you could
# receive an error relayed back to you from that function.
#

  my (%error_desc_list) = qw (
    2 EPERM
    3 ENOENT
    7 EEXIST
    10 EBADF
    13 ENOMEM
    14 EACCES
    17 EBUSY
    19 EXDEV
    20 ENODEV
    21 ENOTDIR
    22 EISDIR
    23 EINVAL
    25 EMFILE
    27 ETXTBSY
    29 ENOSPC
    30 ESPIPE
    35 FS_ERANGE
    37 ENAMETOOLONG
    40 ENOTEMPTY
    41 ELOOP
    302 ENOCARD
    303 EBADFMT
    304 ENOTITM
    513 EFS_invalid_status
    514 EFS_invalid_bytes_read
    515 EFS_fd_mismatch
    516 EFS_path_too_long
    525 EFS_cmd_resp_mismatch
    528 EFS_wr_offset_mismatch
    530 EFS_incompat_version
    533 EFS_bad_cmd_response);

  print "OLE error:\n";

  my ($error_hex) = sprintf "%08lx", $error + 0;

  my ($description) = Variant(VT_BSTR | VT_BYREF, "");
  my ($guid)        = Variant(VT_BSTR | VT_BYREF, "");
  my ($help_ctx)    = Variant(VT_I4   | VT_BYREF,  0);
  my ($help_file)   = Variant(VT_BSTR | VT_BYREF, "");
  my ($prog_src)    = Variant(VT_BSTR | VT_BYREF, "");

  # Calling GetLastError resets the saved error information.
  $efs_obj->GetLastError($description, $guid, $help_ctx, $help_file, $prog_src);

  my $context_text = $error_desc_list{$help_ctx};
  if (!defined $context_text)
  {
    $context_text = $help_ctx;
  }

# For more information on IErrorInfo, look up this topic on msdn.microsoft.com, or
# try the following URL:
# http://msdn.microsoft.com/library/default.asp?url=/library/en-us/automat/html/4dda6909-2d9a-4727-ae0c-b5f90dcfa447.asp

  print "HRESULT:                 <$error_hex>\n";
  print "IErrorInfo description:  <$description>\n";
  print "IErrorInfo help file:    <$help_file>\n";
  print "IErrorInfo help context: <$context_text>\n";
  print "IErrorInfo error source: <$prog_src>\n";
  print "IErrorInfo error intf:   <$guid>\n";
}

# Avoid nonsensical "efs_error.pm did not return a true value at..." error.
1;

