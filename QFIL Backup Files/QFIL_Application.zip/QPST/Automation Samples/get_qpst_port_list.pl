###############################################################################
# (c) Qualcomm Technologies Inc. 2013
#
# Demonstrates various types of identification information QPST can
# retrieve from a device (state, s/w build name, device name, etc.).
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

sub get_meid {
   my ($server, $port_name) = @_;
   my $NV_MEID_I = 1943;
   my $port = $server->GetPort($port_name);
   my $prov = $port->Provisioning;
   my $meid = $prov->GetNVItem($NV_MEID_I);

   undef $prov;
   undef $port;

   if ((defined $meid) && (128 == length $meid)) {
      my @reply_values = unpack "L2x120", $meid;
      my $meid_str = sprintf "%08X%08X", $reply_values[1], $reply_values[0];
      return $meid_str;
   } else {
      return undef;
   }
}

sub get_esn {
   my ($server, $port_name) = @_;

   my $DIAG_ESN_F = 1;
   my $timeout_in_ms = 2000;
   my $port = $server->GetPort($port_name);
   my $diag_cmd = pack "C", $DIAG_ESN_F;
   my $diag_request_var = Variant(VT_ARRAY | VT_UI1, length $diag_cmd);

   $diag_request_var->Put($diag_cmd);

   my $diag_reply = $port->SendCommand($diag_request_var, $timeout_in_ms);

   my @esn_resp = unpack "CL", $diag_reply;

   undef $port;

   if ($DIAG_ESN_F == $esn_resp[0]) {
      return sprintf "%08X", $esn_resp[1];
   } else {
      return undef;
   }
}

sub get_device_info {
  my ($server, $port_name) = @_;

  my $DIAG_EXT_BUILD_ID_F = 124;
  my $timeout_in_ms = 2000;
  my $port = $server->GetPort($port_name);
  my $diag_cmd = pack "C", $DIAG_EXT_BUILD_ID_F;
  my $diag_request_var = Variant(VT_ARRAY | VT_UI1, length $diag_cmd);

  $diag_request_var->Put($diag_cmd);

  my $diag_reply = $port->SendCommand($diag_request_var, $timeout_in_ms);
  my @xbid_values = unpack "C4L2c*", $diag_reply;

  undef $port;

  if ($DIAG_EXT_BUILD_ID_F == $xbid_values[0]) {

     my @build = ();
     my $text = "";

     # $xbid_values[6] is the first character of the first string.
     for ($i = 6; $i <= $#xbid_values; ++$i)
     {
       my $value = $xbid_values[$i];

       # Is this the null terminator?
       if ($value == 0)
       {
         # Finish this string and go on to the next.
         push(@build, $text);
         $text = "";
         next;
       }
       $text = $text . chr $value;
     }
 
     # hw ID, model ID, build name, model name
     return ($xbid_values[4], $xbid_values[5], $build[0], $build[1]);
  } else {
     # Command failed.
     return (undef, undef, undef, undef);
  }
}

sub get_qpst_dev_name {
   my ($server, $port_name) = @_;
   my $port = $server->GetPort($port_name);

   if (defined $port) {
      return $port->DeviceName();
   } else {
      return undef;
   }
}

# Translate phone mode to string.
%phone_mode_list = qw (
  0 none
  2 download
  3 diag_online
  4 diag_offline
  6 stream_download
  12 sahara);

# Translate phone status to string.
%phone_status_list = qw (
  0 no_phone
  1 init_state
  2 port_not_present
  3 phone_not_present
  4 phone_not_supported
  5 ready);

if (defined $qpst)
{
  my $port_list = $qpst->GetPortList();
  my $phone_count = $port_list->PhoneCount;

  for (my $i = 0 ; $i < $phone_count ; ++$i)
  {
    my $port_name = $port_list->PortName($i);
    my $port_build = $port_list->BuildId($i);
    my $phone_mode = $phone_mode_list{$port_list->PhoneMode($i)};
    my $phone_status = $phone_status_list{$port_list->PhoneStatus($i)};

    print "\n";
    print "port name    [$i] : $port_name\n";
    print "port status  [$i] : $phone_status\n";
    print "port mode    [$i] : $phone_mode\n";

    if (("ready" eq $phone_status) &&
        (("diag_online" eq $phone_mode) || ("diag_offline" eq $phone_mode))) {

      print "port build   [$i] : $port_build\n";

      my $meid_str = get_meid($qpst, $port_name);
      my ($hw_id, $model_id, $build_id, $dev_name) = get_device_info($qpst, $port_name);
      my $esn = get_esn($qpst, $port_name);
      my $qpst_name = get_qpst_dev_name($qpst, $port_name);

      if (defined $meid_str) {
         print "MEID         [$i] : $meid_str\n";
      }
      if (defined $esn) {
         print "ESN          [$i] : $esn\n";
      }
      if (defined $hw_id) {
         my $hw_id_str = sprintf "0x%08X", $hw_id;
         print "ext hw ID    [$i] : $hw_id_str\n";
      }
      if (defined $model_id) {
         print "ext model ID [$i] : $model_id\n";
      }
      if (defined $build_id) {
         print "ext build ID [$i] : $build_id\n";
      }
      if ((defined $dev_name) && ($dev_name ne "")){
         print "ext dev name [$i] : $dev_name\n";
      }
      if (defined $qpst_name) {
         print "QPST device  [$i] : $qpst_name\n";
      }
    }
  }

  undef $port_list;
}

# Release the automation server.
undef $qpst;

print "Done!\n";