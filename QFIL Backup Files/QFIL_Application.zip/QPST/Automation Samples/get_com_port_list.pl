use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

# Show (1) the $prod_id GUI or hide (0) it?
$show_gui = 0;

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

# Show the Automation server GUI. Off by default.
if ($show_gui)
{
  $qpst->ShowWindow();

  print "Select a mobile on the GUI and press enter to continue...";
  <STDIN>;
}

###############################################################################
#
# List ports in use by QPST and ports available on the system.
#
###############################################################################

if (defined $qpst)
{
  $port_list = $qpst->GetCOMPortList();
  $port_count = $port_list->PortCount;

  for ($i = 0 ; $i < $port_count ; ++$i)
  {
    # COM port name (e.g. "COM1")
    $port_name = $port_list->PortName($i);

    # PortType will return one of these strings:
    #
    # You can add or remove these port types:
    # "Serial" - conventional UART serial port
    # "USB/Unknown" - Unknown type USB COM port
    # "USB/QC Data Modem" - Qualcomm data modem
    # "USB/QC Diagnostic" - Qualcomm diagnostic port
    # "USB/QC NMEA" - Qualcomm gpsOne
    #
    # QPST only works with "Serial" or "USB/QC Diagnostic"
    #
    # You can only remove these port types:
    # "Assigned" - a disconnected USB phone, port still assigned to QPST
    # "Waiting" - a disconnected USB phone from a previous QPST session
    #
    $port_type = $port_list->PortType($i);
    
    # Returns boolean indicating whether port already in use by QPST.
    $assigned = $port_list->AssignedToQPST($i);

    # DeviceDescription not generally useful. Only applies to USB devices.
    # For a "USB/Unknown" device driver this string may provide the information
    # needed to differentiate the type of port (data, diag, NMEA, not a phone, etc.).
    #$description = $port_list->DeviceDescription($i);

    print "\n";
    print "port name   [$i] : $port_name\n";
    print "port type   [$i] : $port_type\n";
    print "assigned    [$i] : $assigned\n";
    #print "description [$i] : $description\n";
  }

  undef $port_list;
}

if ($show_gui)
{
  print "Press enter to exit script";
  <STDIN>;
}

# Release the automation server.
undef $qpst;

print "Done!\n";