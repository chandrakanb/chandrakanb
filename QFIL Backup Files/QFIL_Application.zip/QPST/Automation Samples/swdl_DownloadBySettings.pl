###############################################################################
# (c) Qualcomm, Inc. 2010
#
# This script demonstrates the new DownloadBySettings() interface for Software
# Download.
# 
# It's advantage is that you can retrieve a DownloadSettings object that is
# initialized for a specific device, and then change some of its settings.
# If the phone changes COM ports when it changes to download mode, you can
# also continue the download on the new COM port (you will have to provide
# the logic to locate the new COM port and add it to the QPST server).
# 
# You can also download to a phone that is already in download mode (for
# example a phone with blank flash in emergency download mode), by
# configuring the DownloadSettings object. This process is not possible with
# the other software download automation APIs.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

my $prod_id = "QPSTAtmnServer.Application";
my $qpst = undef;

# Example emergency downloader file for a phone stuck in download mode.
my $emergFlashPrg = "emmcbld.hex";

# Get a handle to the QPST Automation server.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Cannot start $prod_id";
}

print "Enter path to image files and flash programmer: ";
chomp(my $phoneImageDir = <STDIN>);

# Insure terminated with "\".
unless ("\\" eq substr $phoneImageDir, -1, 1)
{
   $phoneImageDir  = $phoneImageDir . "\\";
}

if (-d $phoneImageDir) {
}
else {
   die "$phoneImageDir not a directory";
}

if (defined $qpst)
{
  my $qpst_version = $qpst->AppVersion;
  print "Using QPST $qpst_version\n";

  print "Enter COM port name or press Enter to select from GUI: ";
  chomp(my $port_name = <STDIN>);

  my $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  if (defined $port)
  {
    $software_download = $port->SoftwareDownload;

    if (defined $software_download)
    {
       # Get the DownloadSettings object for this port.
       $swdl_settings = $software_download->DownloadSettings;

       if (defined $swdl_settings)
       {
          if ($swdl_settings->IsKnownConfiguration)
          {
             # If we get here the phone already has AMSS running and QPST recognizes the device.
             # The DownloadSettings object has been initialized with the same configuration
             # as the GUI-based software download application.
             print "IsKnownConfiguration = true\n";

             # $qpstDir must end with \ so we can concatenate the file name.
             # Remember if you use "\" in a file path you must precede it with an escape: "\\"
             my $qpstDir = "C:\\Program Files\\Qualcomm\\QPST\\";

             my $nvBackupFile = "";

             if (-d $qpstDir) {
                $nvBackupFile = $qpstDir . "test.qcn";

                print "Backup NV items to $nvBackupFile? (y/n) ";
                chomp (my $doQcn = <STDIN>);

                if ($doQcn =~ /^(y(|e(|s)))\b/i) {
                   print "Will perform NV backup...\n";
                }
                else {
                   $nvBackupFile = "";
                }
             }
             else {
                print "Backup dirctory $qpstDir does not exist, NV backup/restore disabled.\n";
             }

             # Note- after every SetParam you should use:
             # $error = 0 + Win32::OLE->LastError();
             # to test for an error. $error != 0 indicates the SetParam returned an error code.
             # To simplify this example, only the result of DownloadBySettings is tested for error.

             # When you call DownloadBySettings() the default path
             # (phoneimagepath) is applied to any image file that
             # doesn't contain either a drive or directory component.
             # 
             # SetParam for any file must specify a path to a file that exists.
             # SetParam does not use phoneimagepath as a default path for the file.
             # A common error would be to just give the file name:
             #   SetParam("filepathDbl", "mydbl.mbn")
             # In this case SetParam would only work if "mydbl.mbn" existed in the
             # default directory used by the automation server component.
             # 
             # All *.mbn files are optional, however:
             # 1) The flash programmer file must always exist.
             # 2) The partition file must exist for NAND flash.
             $swdl_settings->SetParam("phoneimagepath", $phoneImageDir);

             # prlrestoremode:
             # "always" - always try to restore the PRL. Will fail if the PRL writes to a SIM/UIM card.
             # "rtre_config nv_only" - restore only if PRL writes to NV (actually a EFS file).
             $swdl_settings->SetParam("prlrestoremode", "rtre_config nv_only");

             # Set a path for NV backup/restore. To skip the backup don't set this parameter.
             if ($nvBackupFile ne "") {
                $swdl_settings->SetParam("filepathqcn", $nvBackupFile);
             }

             # Default SPC is "000000".
             #$swdl_settings->SetParam("SPC", "000001");

             # Override partition table. Default is false ("0").
             # $swdl_settings->SetParam("overridePrtnTable", "0");

             # Clear phone error log. Default is true ("1").
             #$swdl_settings->SetParam("clearPhoneErrorLog", "1");
          }
          else
          {
             # If we get here the phone is stuck in download mode or QPST doesn't recognize
             # the device.
             print "IsKnownConfiguration = false\n";

             # Default is true ("1") - don't send PBL, it is built-in to the chip.
             $swdl_settings->SetParam("useTrustedMode", "1");

             # downloadTarget:
             # "nor" - NOR flash (presently not suppported).
             # "nand sb 1.0" - NAND flash, Secure Boot 1.0 (presently not supported).
             # "nand sb 2.0" - NAND flash, Secure Boot 2.0
             # "nand sb 2.0 boot only" - NAND flash, Secure Boot 2.0, only dbl, fsbl, osbl.
             $swdl_settings->SetParam("downloadTarget", "nand sb 2.0");
             #$swdl_settings->SetParam("downloadTarget", "nand sb 2.0 boot only");

             # Set default path that DownloadBySettings() will use to find image files.
             $swdl_settings->SetParam("phoneimagepath", $phoneImageDir);

             # Must specify the full path of the flash programmer. Any file specification
             # used with SetParam must evaluate as a file that exists.
             $swdl_settings->SetParam("flashprogrammer", $phoneImageDir . $emergFlashPrg);

             # Skip reset of phone at end of download. Default is false ("0").
             #$swdl_settings->SetParam("skipreset", "0");

             # Wait time for phone to restart (seconds).
             $swdl_settings->SetParam("restart timeout", "5");
          }

          # Can only use GetParam with "devicename".
          my $dev_name = $swdl_settings->GetParam("devicename");
          print "devicename = \"$dev_name\"\n";

          my $spc = $swdl_settings->GetParam("SPC");
          print "SPC = \"$spc\"\n";

          my $opTab = $swdl_settings->GetParam("overridePrtnTable");
          print "overridePrtnTable = $opTab\n";

          my $modeTrusted = $swdl_settings->GetParam("useTrustedMode");
          print "useTrustedMode = $modeTrusted\n";

          my $clrErrLog = $swdl_settings->GetParam("clearPhoneErrorLog");
          print "clearPhoneErrorLog = $clrErrLog\n";

          my $prlRest = $swdl_settings->GetParam("prlrestoremode");
          print "prlrestoremode = $prlRest\n";

          my $dlTarget = $swdl_settings->GetParam("downloadTarget");
          print "downloadTarget = \"$dlTarget\"\n";

          my $qcnPath = $swdl_settings->GetParam("filepathqcn");
          print "filepathqcn = $qcnPath\n";

          my $defPath = $swdl_settings->GetParam("phoneimagepath");
          print "phoneimagepath = \"$defPath\"\n";

          my $mbnPartition = $swdl_settings->GetParam("filepathpartition");
          print "filepathpartition = \"$mbnPartition\"\n";

          my $fp_name = $swdl_settings->GetParam("flashprogrammer");
          print "flashprogrammer = $fp_name\n";

          my $mbnDbl = $swdl_settings->GetParam("filepathDbl");
          print "filepathDbl = \"$mbnDbl\"\n";

          my $mbnFsbl = $swdl_settings->GetParam("filepathFsbl");
          print "filepathFsbl = \"$mbnFsbl\"\n";

          my $mbnOsbl = $swdl_settings->GetParam("filepathOsbl");
          print "filepathOsbl = \"$mbnOsbl\"\n";

          my $mbnAmss = $swdl_settings->GetParam("filepathAmss");
          print "filepathAmss = \"$mbnAmss\"\n";

          my $mbnApps = $swdl_settings->GetParam("filepathApps");
          print "filepathApps = \"$mbnApps\"\n";

          my $mbnAppsBoot = $swdl_settings->GetParam("filepathAppsBoot");
          print "filepathAppsBoot = \"$mbnAppsBoot\"\n";

          my $mbnWM = $swdl_settings->GetParam("filepathWM");
          print "filepathWM = \"$mbnWM\"\n";

          my $mbnDsp1 = $swdl_settings->GetParam("filepathDSP1");
          print "filepathDSP1 = \"$mbnDsp1\"\n";

          my $mbnDsp2 = $swdl_settings->GetParam("filepathDSP2");
          print "filepathDSP2 = \"$mbnDsp2\"\n";

          my $mbnAdsp = $swdl_settings->GetParam("filepathADSP");
          print "filepathADSP = \"$mbnAdsp\"\n";

          my $mbnTzos = $swdl_settings->GetParam("filepathTZOS");
          print "filepathTZOS = \"$mbnTzos\"\n";

          my $restartTimeout = $swdl_settings->GetParam("restart timeout");
          print "restart timeout = $restartTimeout\n";

          # Start the download. Will wait here until it completes or fails.
          # DownloadBySettings() will download any files found for the specified "downloadTarget".
          # It will skip any missing files.
          $software_download->DownloadBySettings($swdl_settings);

          # Error returned by call to DownloadBySettings?
          my $error = 0 + Win32::OLE->LastError();

          # Error during download?
          my $error_message = $software_download->GetErrorMessage();

          if ($error)
          {
             print "Error returned by DownloadBySettings:\n";
             print "Final status <$error_message>\n";
          }
          else
          {
             if ($error_message eq "")
             {
                print "Download completed successfully\n";
             }
             else
             {
                print "Download completed with error:\n";
                print "Final status <$error_message>\n";
             }
          }

          undef $swdl_settings;
       }
       else
       {
          print "Failed to access DownloadSettings component\n";
       }

       undef $software_download;
    }
    else
    {
       print "Failed to access SoftwareDownload component\n";
    }

    undef $port;
  }
  else
  {
    print "Port not available\n";
  }

  undef $qpst;
}
else
{
  print "QPST not available\n";
}

sub print_error
{
  my ($error, $error_obj) = @_;

  print "OLE error:\n";

  my ($error_hex) = sprintf "%08lx", $error + 0;

  my ($description) = Variant(VT_BSTR | VT_BYREF, "");
  my ($guid)        = Variant(VT_BSTR | VT_BYREF, "");
  my ($help_ctx)    = Variant(VT_I4   | VT_BYREF,  0);
  my ($help_file)   = Variant(VT_BSTR | VT_BYREF, "");
  my ($prog_src)    = Variant(VT_BSTR | VT_BYREF, "");

  # Calling GetLastError resets the saved error information.
  $error_obj->GetLastError($description, $guid, $help_ctx, $help_file, $prog_src);

# For more information on IErrorInfo, look up this topic on msdn.microsoft.com, or
# try the following URL:
# http://msdn.microsoft.com/library/default.asp?url=/library/en-us/automat/html/4dda6909-2d9a-4727-ae0c-b5f90dcfa447.asp

  print "HRESULT:                 <$error_hex>\n";
  print "IErrorInfo description:  <$description>\n";
  print "IErrorInfo help file:    <$help_file>\n";
  print "IErrorInfo help context: <$help_ctx>\n";
  print "IErrorInfo error source: <$prog_src>\n";
  print "IErrorInfo error intf:   <$guid>\n";
}

