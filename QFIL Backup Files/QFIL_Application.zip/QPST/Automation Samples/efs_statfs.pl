###############################################################################
# (c) Qualcomm, Inc. 2006
#
# Demonstrate use of StatFS.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;
use efs_error;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

if (defined $qpst)
{
  print "Enter COM port name or press Enter to select from GUI: ";
  $port_name = <STDIN>;
  chomp($port_name);

  $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  # Translate phone status to string.
  %phone_status_list = qw (
    0 phoneStatusNone
    5 phoneStatusReady);

  if (defined $port)
  {
    $port_name = $port->PortName;
    print "port $port_name\n";

    $port_status = $port->PhoneStatus;

    if ($phone_status_list{$port_status} eq "phoneStatusReady")
    {
      $efs = $port->EFS;

      if (defined $efs)
      {
        $version = $efs->EFSVersion;
        print "EFS version $version\n";

        if ($version == 2)
        {
          print "EFS path ? ";
          $efs_path = <STDIN>;
          chomp($efs_path);

          if ($efs_path ne "")
          {
            $fs_id       = Variant(VT_I4   | VT_BYREF, 0);
            $fs_type     = Variant(VT_BSTR | VT_BYREF, "");
            $blk_size    = Variant(VT_I4   | VT_BYREF, 0);
            $tot_blks    = Variant(VT_I4   | VT_BYREF, 0);
            $avail_blks  = Variant(VT_I4   | VT_BYREF, 0);
            $free_blks   = Variant(VT_I4   | VT_BYREF, 0);
            $max_size    = Variant(VT_I4   | VT_BYREF, 0);
            $n_files     = Variant(VT_I4   | VT_BYREF, 0);
            $max_n_files = Variant(VT_I4   | VT_BYREF, 0);

            $efs->StatFS($efs_path,  $fs_id,
                         $fs_type,   $blk_size,
                         $tot_blks,  $avail_blks,
                         $free_blks, $max_size,
                         $n_files,   $max_n_files);

            $error = 0 + Win32::OLE->LastError();

            if ($error == 0)
            {
              print "fs id       : $fs_id\n";
              print "fs type     : \"$fs_type\"\n";
              print "blk size    : $blk_size\n";
              print "tot blks    : $tot_blks\n";
              print "avail blks  : $avail_blks\n";
              print "free blks   : $free_blks\n";
              print "max size    : $max_size\n";
              print "n files     : $n_files\n";
              print "max n files : $max_n_files\n";
            }
            else
            {
              print_error($error, $efs);
            }
          }
        }
        else
        {
          print "Incompatible EFS version\n";
        }
      }
      else
      {
        print "No EFS interface for this port\n";
      }

      undef $efs;
    }
    else
    {
      print "Phone not ready\n";
    }
  }
  else
  {
    print "Port not available\n";
  }

  undef $port;
}
else
{
  print "QPST not available\n";
}

undef $qpst;

sub print_error
{
  my ($error, $efs_obj) = @_;

  my (%error_desc_list) = qw (
    2 EPERM
    3 ENOENT
    7 EEXIST
    10 EBADF
    13 ENOMEM
    14 EACCES
    17 EBUSY
    19 EXDEV
    20 ENODEV
    21 ENOTDIR
    22 EISDIR
    23 EINVAL
    25 EMFILE
    27 ETXTBSY
    29 ENOSPC
    30 ESPIPE
    35 FS_ERANGE
    37 ENAMETOOLONG
    40 ENOTEMPTY
    41 ELOOP
    302 ENOCARD
    303 EBADFMT
    304 ENOTITM
    513 EFS_invalid_status
    514 EFS_invalid_bytes_read
    515 EFS_fd_mismatch
    516 EFS_path_too_long
    525 EFS_cmd_resp_mismatch
    528 EFS_wr_offset_mismatch
    530 EFS_incompat_version
    533 EFS_bad_cmd_response);

  my ($error_hex) = sprintf "%08lx", $error + 0;
  my ($description) = Variant(VT_BSTR | VT_BYREF, "");
  my ($guid)        = Variant(VT_BSTR | VT_BYREF, "");
  my ($help_ctx)    = Variant(VT_I4   | VT_BYREF,  0);
  my ($help_file)   = Variant(VT_BSTR | VT_BYREF, "");
  my ($prog_src)    = Variant(VT_BSTR | VT_BYREF, "");

  $efs_obj->GetLastError($description, $guid, $help_ctx, $help_file, $prog_src);

  $context_text = $error_desc_list{$help_ctx};
  if (!defined $context_text)
  {
    $context_text = $help_ctx;
  }

  print "OLE error:\n";
  print "HRESULT:                 <$error_hex>\n";
  print "IErrorInfo description:  <$description>\n";
  print "IErrorInfo help file:    <$help_file>\n";
  print "IErrorInfo help context: <$context_text>\n";
  print "IErrorInfo error source: <$prog_src>\n";
  print "IErrorInfo error intf:   <$guid>\n";
}