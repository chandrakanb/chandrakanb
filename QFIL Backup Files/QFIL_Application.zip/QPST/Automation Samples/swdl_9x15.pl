###############################################################################
# (c) Qualcomm, Inc. 2012
#
# This script demonstrates the new DownloadBySettings() interface for Software
# Download.
# 
# It's advantage is that you can retrieve a DownloadSettings object that is
# initialized for a specific device, and then change some of its settings.
# If the phone changes COM ports when it changes to download mode, you can
# also continue the download on the new COM port (you will have to provide
# the logic to locate the new COM port and add it to the QPST server).
# 
# You can also download to a phone that is already in download mode (for
# example a phone with blank flash in emergency download mode), by
# configuring the DownloadSettings object. This process is not possible with
# the other software download automation APIs.
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

my $prod_id = "QPSTAtmnServer.Application";
my $qpst = undef;

# Get a handle to the QPST Automation server.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Cannot start $prod_id";
}

if (defined $qpst)
{
  my $qpst_version = $qpst->AppVersion;
  print "Using QPST $qpst_version\n";

  print "Enter COM port name or press Enter to select from GUI: ";
  chomp(my $port_name = <STDIN>);

  my $port = undef;

  if ($port_name eq "")
  {
    $qpst->ShowWindow();

    print "Select a phone on the GUI,\nthen return to this window and press enter to continue";
    <STDIN>;

    $port = $qpst->GetSelectedPort();
  }
  else
  {
    $port = $qpst->GetPort($port_name);
  }

  if (defined $port)
  {
    $software_download = $port->SoftwareDownload;

    if (defined $software_download)
    {
       # Reset maximum time per operation state to 15 minutes.
       $software_download->{ImageDownloadTimeout} = 15;

       # Get the DownloadSettings object for this port.
       $swdl_settings = $software_download->DownloadSettings;

       if (defined $swdl_settings)
       {
          # Note- after every SetParam you should use:
          # $error = 0 + Win32::OLE->LastError();
          # to test for an error. $error != 0 indicates the SetParam returned an error code.
          # To simplify this example, only some result are tested for errors.

          # REQUIRED settings.
 
          # Must set the search path BEFORE userPartitionList, filePathUserPartition, or flashProgrammer.
          $swdl_settings->SetParam("searchPaths", "e:\\Phone_Builds\\test_data\\;e:\\Phone_Builds\\test_data2\\");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam searchPaths\n";
             print_error($last_error, $swdl_settings);
          }

          $swdl_settings->SetParam("usetrustedmode", "1");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam usetrustedmode\n";
             print_error($last_error, $swdl_settings);
          }
          # NEW setting - all mbn files specified here must exist on a search path ("searchPaths").
          # The format is a list of partition=file seperated by ";".
          $swdl_settings->SetParam("userPartitionList", "0:DSP1=dsp1.mbn;0:DSP2=dsp2.mbn");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam userPartitionList\n";
             print_error($last_error, $swdl_settings);
          }

          # downloadTarget:
          $swdl_settings->SetParam("downloadTarget", "nand user partition");
          $last_error = 0 + Win32::OLE->LastError();
          if ($last_error) {
             print "SetParam downloadTarget\n";
             print_error($last_error, $swdl_settings);
          }
     
          # Optional settings. These settings override a default behavior.

          # partition.mbn must exist somewhere on "searchPaths".
          # If not, you will have to set it here using the full file path
          #$swdl_settings->SetParam("filepathuserpartition", $fullPartitionFilePath);

          if ($swdl_settings->IsKnownConfiguration)
          {
             # If we get here the phone already has AMSS running and QPST recognizes the device.
             # The DownloadSettings object has been initialized with the same configuration
             # as the GUI-based software download application.
             print "IsKnownConfiguration = true\n";

             # NV backup is not supported. It must be done seperately. 

             # Override the automatic choice of flash programmer if you wish.
             # Must specify the full path of the flash programmer, or it must exist on "searchPaths".
             #$swdl_settings->SetParam("flashprogrammer", "nprg9x15.hex");
         }
          else
          {
             # If we get here the phone is stuck in download mode or QPST doesn't recognize
             # the device.
             print "IsKnownConfiguration = false\n";

             # Must specify the full path of the flash programmer, or it must exist on "searchPaths".
             $swdl_settings->SetParam("flashprogrammer", "nprg9x15.hex");
          }

          # Can only use GetParam with "devicename".
          my $dev_name = $swdl_settings->GetParam("devicename");
          print "devicename = \"$dev_name\"\n";

          my $spath = $swdl_settings->GetParam("searchPaths");
          print "search paths = $spath\n";

          my $dlTarget = $swdl_settings->GetParam("downloadTarget");
          print "downloadTarget = \"$dlTarget\"\n";

          my $mbnPartition = $swdl_settings->GetParam("filepathuserpartition");
          print "filepathuserpartition = \"$mbnPartition\"\n";

          my $fp_name = $swdl_settings->GetParam("flashprogrammer");
          print "flashprogrammer = $fp_name\n";

          my $userPrtns = $swdl_settings->GetParam("userPartitionList");
          print "user partition list = $userPrtns\n";

          # Start the download. Will wait here until it completes or fails.
          $software_download->DownloadBySettings($swdl_settings);

          # Error returned by call to DownloadBySettings?
          my $error = 0 + Win32::OLE->LastError();

          # Error during download?
          my $error_message = $software_download->GetErrorMessage();

          # Note - examining flashprogrammer and filepathuserpartition after the call to
          # DownloadBySettings() will show the full file path.

          # Show the full path for the flash programmer.
          my $fp_name2 = $swdl_settings->GetParam("flashprogrammer");
          print "used flashprogrammer = $fp_name2\n";

          # Show the full path for the flash partition file.
          my $mbnPartition2 = $swdl_settings->GetParam("filepathuserpartition");
          print "used filepathuserpartition = \"$mbnPartition2\"\n";

          if ($error)
          {
             print "Error returned by DownloadBySettings:\n";
             print "Final status <$error_message>\n";
          }
          else
          {
             if ($error_message eq "")
             {
                print "Download completed successfully\n";
             }
             else
             {
                print "Download completed with error:\n";
                print "Final status <$error_message>\n";
             }
          }

          undef $swdl_settings;
       }
       else
       {
          print "Failed to access DownloadSettings component\n";
       }

       undef $software_download;
    }
    else
    {
       print "Failed to access SoftwareDownload component\n";
    }

    undef $port;
  }
  else
  {
    print "Port not available\n";
  }

  undef $qpst;
}
else
{
  print "QPST not available\n";
}

sub print_error
{
  my ($error, $error_obj) = @_;

  print "OLE error:\n";

  my ($error_hex) = sprintf "%08lx", $error + 0;

  my ($description) = Variant(VT_BSTR | VT_BYREF, "");
  my ($guid)        = Variant(VT_BSTR | VT_BYREF, "");
  my ($help_ctx)    = Variant(VT_I4   | VT_BYREF,  0);
  my ($help_file)   = Variant(VT_BSTR | VT_BYREF, "");
  my ($prog_src)    = Variant(VT_BSTR | VT_BYREF, "");

  # Calling GetLastError resets the saved error information.
  $error_obj->GetLastError($description, $guid, $help_ctx, $help_file, $prog_src);

# For more information on IErrorInfo, look up this topic on msdn.microsoft.com, or
# try the following URL:
# http://msdn.microsoft.com/en-us/library/4dda6909-2d9a-4727-ae0c-b5f90dcfa447(VS.85)

  print "HRESULT:                 <$error_hex>\n";
  print "IErrorInfo description:  <$description>\n";
  print "IErrorInfo help file:    <$help_file>\n";
  print "IErrorInfo help context: <$help_ctx>\n";
  print "IErrorInfo error source: <$prog_src>\n";
  print "IErrorInfo error intf:   <$guid>\n";
}

