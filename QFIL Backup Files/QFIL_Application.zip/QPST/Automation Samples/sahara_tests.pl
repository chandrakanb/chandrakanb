###############################################################################
# (c) Qualcomm Technologies Inc. 2013
#
# Demonstrates new Automation methods that support the Sahara data transfer
# protocol (crash dump and software download).
#
# New APIs for Sahara mode:
#  SaharaHelloRsp()
#  EnableSaharaSupport()
#  EnableDumpTimeStamp()
#  EnableSaharaAutoReset()
#  LastSaharaEvent()
#  SaharaConfigXML()
#  XmlPath()
#  PathOneTimeUse()
#  MemoryDumpFolder()
#  SendSaharaResetCmd()
#  SaharaAbortDumpAndReset()
#
###############################################################################

use Win32::OLE;
use Win32::OLE::Variant;

###############################################################################

# AppId for the Automation server.
my $prod_id = "QPSTAtmnServer.Application";

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

%phone_mode_list = qw (
  0  no_phone
  2  download
  3  diag_online
  4  diag_offline
  6  stream_download
  12 sahara);

%hello_rsp_list = qw (
  0 default
  1 dump_not_download
  2 download_not_dump
  3 wait_for_selection);

if (defined $qpst)
{
   print "Enter COM port name: ";
   my $port_name = <STDIN>;
   chomp($port_name);

   my $port = undef;

   if ($port_name ne "")
   {
      $port = $qpst->GetPort($port_name);
   }

   if (defined $port)
   {
      # Display initial QPST configuration state.

      # See (11).
      my $hello_action = $hello_rsp_list{$port->SaharaHelloRsp()};
      print "==> Response to Hello is: $hello_action\n";

      my $phone_mode = $port->PhoneMode();
      my $phone_mode_name = $phone_mode_list{$phone_mode};

      print "==> Phone mode is $phone_mode_name\n";

      my $init_enable = $port->EnableSaharaSupport();

      if ($init_enable)
      {
         print "==> Sahara support is enabled\n";
      } else {
         print "==> Sahara support is disabled\n";
      }

      if ($port->EnableDumpTimeStamp())
      {
         print "==> Dump timestamp is enabled\n";
      } else {
         print "==> Dump timestamp is disabled\n";
      }

      if ($port->EnableSaharaAutoReset())
      {
         print "==> Dump auto reset is enabled\n";
      } else {
         print "==> Dump auto reset is disabled\n";
      }

      # Display menu.
      my $mode_check = "";
      if (12 != $phone_mode) {
         $mode_check = "(phone in wrong mode!)";
      }

      # See (6).
      my $crash_check = $mode_check;
      my $init_event = $port->LastSaharaEvent();
      if ((19 != $init_event) && (20 != $init_event)) {
         $crash_check = "(no crash in progress!)";
      }

      print "1:  enable/disable Sahara support\n";
      print "2:  set download XML path and 1-time flag\n";
      print "3:  get XML path/flag\n";
      print "4:  set memory dump folder\n";
      print "5:  get memory dump folder\n";
      print "6:  get last Sahara event\n";
      print "7:  enable/disable dump timestamp\n";
      print "8:  enable/disable dump auto reset\n";
      print "9:  send Sahara reset command $mode_check\n";
      print "10: abort crash dump and reset device $crash_check\n";
      print "11: set Hello response action\n";
      print "\n";
      print "Enter selection: ";

      my $op_selected = <STDIN>;
      chomp($op_selected);

      if (1 == $op_selected) {

         ###############################################################################
         # enable/disable Sahara support
         #
         # If Sahara support is disabled the QPST port server will act as it did before QPST version 2.7.388.
         # By default Sahara is enabled when QPST opens a COM port.
         #
         # You should leave Sahara mode enabled. If you want QPST to pause when the device enters
         # Sahara mode, set $port->{SaharaHelloRsp} = 3; See (11) below.
         ###############################################################################

         print "Enable Sahara support (yes/no)?: ";
         my $reply = <STDIN>;
         chomp($reply);

         my $enab_sahara = undef;

         if ($reply =~ /^(y(|e(|s)))\b/i)    # y, ye, yes
         {
           $enab_sahara = 1;
         } elsif ($reply =~ /^(n(|o))\b/i) { # n, no
           $enab_sahara = 0;
         }

         if (defined $enab_sahara)
         {
            $port->{EnableSaharaSupport} = $enab_sahara;
         } else {
            print "setting not changed\n";
         }

      } elsif (2 == $op_selected) {

         ###############################################################################
         # set download XML path and 1-time flag
         #
         # This function allows you to specify an XML file that defines what software images are available
         # to a device if it requests Sahara software download.
         # For flashless boot devices the device will request software download whenever the device reboots.
         # For flash boot devices, the device only uses Sahara software download for the flash programmer.
         #
         # The device will request images by image ID. This XML file establishes a mapping between the image
         # ID and the image's file path. It does NOT specify what images to download. The Sahara protocol DOES
         # NOT allow the host software to choose what images to download - the device will tell the host what
         # images it wants.
         #
         # Example XML contents. This file is device dependant because the images required for download are device dependant.
         # Any relative paths are relative to the XML file itself. 
         #
         #<?xml version="1.0" encoding="utf-8"?>
         #<sahara_config>
         # <images>
         #  <image image_id="21" image_path="..\binaries\sbl1.mbn" programmer="false" />
         #  <image image_id="22" image_path="..\binaries\sbl2.mbn" programmer="false" />
         # </images>
         #</sahara_config>
         #
         # programmer="true" would be only used for a flash programmer image. The Sahara implementation on the device does
         # not go through a normal download termination for a flash programmer. When set to "true" this flag tells the QPST
         # state machine to terminate the download and begin polling the device after sending this image.
         #
         # This is available from the QPST Configuration Port right click menu under
         # "Sahara Configuration...".
         ###############################################################################

         print "Enter XML path: ";
         my $xmlPath = <STDIN>;
         chomp($xmlPath);

         ###############################################################################
         # The one-time flag tells the QPST port server to forget this XML file after the first download.
         ###############################################################################

         print "Use XML one time?: ";
         my $oneTime = <STDIN>;
         chomp($oneTime);

         if ($oneTime =~ /^(y(|e(|s)))\b/i)    # y, ye, yes
         {
            $port->SaharaConfigXML($xmlPath, 1);
         } else {
            $port->SaharaConfigXML($xmlPath, 0);
         }

      } elsif (3 == $op_selected) {

         # get XML path/flag

         my $xmlPath = $port->XmlPath();
         my $oneTime = $port->PathOneTimeUse();
         print "XML path = \"$xmlPath\"\n";
         print "One time = $oneTime\n";

      } elsif (4 == $op_selected) {

         ###############################################################################
         # set memory dump folder
         #
         # By default memory dumps are automatically saved in a folder named after the COM port:
         # \ProgramData\Qualcomm\QPST\Sahara\Port_COMxx
         # Where xx = the COM port number.
         # Note that \ProgramData\Qualcomm\QPST is the QPST data directory folder, and depends on XP / Win7 and system configuration.
         #
         # If you set the memory dump folder with this function, you override the entire default path.
         # However you can enable the folder dump time stamp option (7), but this is not recommended.
         # Ultimately the folder string is passed to SHCreateDirectoryEx for creation. See msdn.microsoft.com for details.
         ###############################################################################

         print "Enter memory dump folder path: ";
         my $dumpPath = <STDIN>;
         chomp($dumpPath);

         $port->{MemoryDumpFolder} = $dumpPath;

      } elsif (5 == $op_selected) {

         ###############################################################################
         # get memory dump folder
         #
         # This will return an empty string if you are using the default memory dump path.
         ###############################################################################

         my $folder = $port->MemoryDumpFolder();
         print "memory debug folder = \"$folder\"\n";

      } elsif (6 == $op_selected) {

         ###############################################################################
         # get last Sahara event
         #
         # This value is initialized to 1 when the COM port is opened.
         # There are only three values returned from this call that have any meaning:
         # 19: memory dump is starting
         # 20: a memory region has been saved
         # 21: memory dump has either completed successfully or failed
         # It is quite likely the memory dump states will change so quickly that you will miss
         # states 19 and 20. LastSaharaEvent will retain its value. It is not changed by software download.
         ###############################################################################

         my $last_event = $port->LastSaharaEvent();
         print "last Sahara event = $last_event\n";

      } elsif (7 == $op_selected) {

         ###############################################################################
         # enable/disable dump timestamp
         #
         # By default memory dumps are automatically saved in a folder named after the COM port:
         # \ProgramData\Qualcomm\QPST\Sahara\Port_COMxx
         # Where xx = the COM port number.
         # Note that \ProgramData\Qualcomm\QPST is the QPST data directory folder, and depends on XP / Win7 and system configuration.
         #
         # Enabling this feature requests a new folder for each crash dump, with a folder name
         # based on the current time, for example:
         # \ProgramData\Qualcomm\QPST\Sahara\Port_COMxx_20130102091011222
         # for a crash dump that occurred on 2-Jan-2013 09:10:11.222
         #
         # Enabling this feature is NOT recommended. Since memory dumps can occupy several
         # gigabytes you can rapidly consume all your free disk space if the device crashes
         # frequently and you don't automatically remove old crash dumps.
         ###############################################################################

         print "Enable dump timestamp (yes/no)?: ";
         my $reply = <STDIN>;
         chomp($reply);

         if ($reply =~ /^(y(|e(|s)))\b/i) {   # y, ye, yes

            $port->{EnableDumpTimeStamp} = 1;

         } elsif ($reply =~ /^(n(|o))\b/i) { # n, no

            $port->{EnableDumpTimeStamp} = 0;

         } else {
            print "setting not changed\n";
         }

      } elsif (8 == $op_selected) {

         ###############################################################################
         # enable/disable dump auto reset
         #
         # When a memory dump completes or fails, send a Sahara reset command to restart the device if this
         # option is enabled (set to 1). It is enabled by default.
         #
         # If you disable auto restart, you can use SendSaharaResetCmd() to reset the device. In this case you should wait
         # until LastSaharaEvent() returns 21 or the reset will fail. However if LastSaharaEvent() returns 19 or 20 you
         # can use SaharaAbortDumpAndReset() to abort the crash dump and reboot the device.
         #
         # This is available from the QPST Configuration Port right click menu under
         # "Sahara Configuration...".
         ###############################################################################

         print "Enable dump auto reset (yes/no)?: ";
         my $reply = <STDIN>;
         chomp($reply);

         if ($reply =~ /^(y(|e(|s)))\b/i) {   # y, ye, yes

            $port->{EnableSaharaAutoReset} = 1;

         } elsif ($reply =~ /^(n(|o))\b/i) { # n, no

            $port->{EnableSaharaAutoReset} = 0;

         } else {
            print "setting not changed\n";
         }

      } elsif (9 == $op_selected) {

         ###############################################################################
         # send Sahara reset command
         #
         # The device must be in Sahara mode or the request will fail immediately.
         # If the device is in Sahara mode but is busy this request will timeout in 3000 ms and return error.
         # The device would be busy if it was requesting software download service or sending a crash dump.
         #
         # This is available from the QPST Configuration Port right click menu under
         # "Send Sahara Reset Command...".
         ###############################################################################

         my $result = $port->SendSaharaResetCmd();

         if (0 == $result) {
            print "Reset failed\n";
         } else {
            print "Reset succeeded\n";
         }
      } elsif (10 == $op_selected) {

         ###############################################################################
         # abort crash dump and reset device
         #
         # The device must be in Sahara mode or the request will fail immediately.
         # If the device is in Sahara mode but the crash dump does not abort in 15000 ms this function will return an error.
         # This timeout would occur if the device was not currently in a crash dump, or if the device had disconnected
         # from USB.
         ###############################################################################

         my $result = $port->SaharaAbortDumpAndReset();

         if (0 == $result) {
            print "Abort+Reset failed\n";
         } else {
            print "Abort+Reset succeeded\n";
         }
      } elsif (11 == $op_selected) {

         ###############################################################################
         # set Hello response action
         #
         # This is available from the QPST Configuration Port right click menu under
         # "Sahara Configuration...".
         ###############################################################################

         print "Upon receiving Sahara Hello...\n";
         print "0 = perform requested action\n";
         print "1 = if a download request, perform a RAM dump instead\n";
         print "2 = if a RAM dump request, perform a download instead\n";
         print "3 = do nothing until one of the other response modes is selected\n";
         print "Enter action value: ";

         my $reply = <STDIN>;
         chomp($reply);

         $port->{SaharaHelloRsp} = int $reply;
      }

      undef $port;
   }

   undef $qpst;
}

print "Done!\n";