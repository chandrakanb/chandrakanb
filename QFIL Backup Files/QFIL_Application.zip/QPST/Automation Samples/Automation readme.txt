8/06

The QPST User's Guide contains reference material for the automation interface in chapter 12.

Sample Perl Scripts:

- COM port control
enumerate.pl         - enumerates active mobiles and shows their state.
get_com_port_list.pl - list ports in use by QPST and available on system
add_remove.pl        - remove all QPST ports and add back just USB ports
enab_disab.pl        - toggle the QPST port enable state

- phone control
offline.pl           - sets a mobile offline.
reset.pl             - resets a mobile.
spc.pl               - unlocks a mobile by sending the Service Provisioning Code.

- EFS
copy_pc_to_phone.pl  - copy a file from the PC to the phone.
copy_phone_to_pc.pl  - copy a file from the phone to the PC.
efs_copy_file.pl     - copy a file within the phone
efs_createdirandwrite.pl - copy a file to the phone, creating directories as necessary.
efs_dir_iter.pl      - iterate the entries in a EFS directory.
efs_file_stat.pl     - display file statistics.
efs_isdirempty.pl    - test if a directory is empty.
efs_lstat.pl         - display file statistics.
efs_mkdir.pl         - create a directory.
efs_params.pl        - return EFS parameters.
efs_read_link.pl     - evaluate a file link.
efs_recursivedir.pl  - recursively list directories.
efs_removetree.pl    - recursively remove a directory tree.
efs_rename.pl        - rename a file.
efs_rmdir.pl         - remove a directory.
efs_statfs.pl        - stat the file system.
efs_symlink.pl       - create a symbolic link.
efs_unlink.pl        - delete a file.
efs_error.pm         - common error handling code.

- Software Download
swdl_cefs_download.pl - download a CEFS file to replace the phone's file system contents.
swdl_mi_download.pl  - multi-image download
swdl_nvbackup.pl     - perform NV item backup
swdl_nvrestore.pl    - perform NV item restore
swdl_otp_download.pl - OTP multi-image download.
swdl_si_nand_download.pl - single-image NAND flash download.
swdl_si_nor_download.pl  - single-image NOR flash download.

Sample VB Scripts:
enumerate.vbs        - enumerates active mobiles and shows their state.
sendcommand.vbs      - sends an NV read command of MIN1 to the mobile.
provisioning.vbs     - gets and sets nv items and roaming list.

