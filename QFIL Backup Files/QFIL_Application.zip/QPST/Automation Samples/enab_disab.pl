# Written for Perl 5.005_03, ActiveState Tool Corp. version 513.

use Win32::OLE;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

# Show (1) the $prod_id GUI or hide (0) it?
$show_gui = 0;

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

# Show the Automation server GUI. Off by default.
if ($show_gui)
{
  $qpst->ShowWindow();

  print "press enter to continue";
  <STDIN>;
}

if (defined $qpst)
{
  print "Toggle port enable/disable state...\n";

  # Can't use this because it only lists enabled ports.
  #$port_list = $qpst->GetPortList();

  $port_list = $qpst->GetCOMPortList();

  if (defined $port_list)
  {
    $port_count = $port_list->PortCount();

    for ($i = 0 ; $i < $port_count ; ++$i)
    {
      # Can only look at the EnablePort state of assigned ports.
      if ($port_list->AssignedToQPST($i))
      {
        # COM port name (e.g. "COM1")
        $port_name = $port_list->PortName($i);

        $enabled = $qpst->EnablePort($port_name);

        if ($enabled)
        {
          print "Disable $port_name? ";
        }
        else
        {
          print "Enable $port_name? ";
        }

        $reply = <STDIN>;
        chomp($reply);

        if ($reply =~ /^(y(|e(|s)))\b/i)    # y, ye, yes
        {
          # Unfortunately this syntax does not compile.
          #$qpst->{EnablePort($port_name)} = !$enabled;

          $qpst->SetProperty('EnablePort', $port_name, !$enabled);
        }
      }
    }

    # Release the port list component.
    undef $port_list;
  }
  else
  {
    print "NO port list returned\n";
  }
}

if ($show_gui)
{
  print "press enter to exit";
  <STDIN>;
}

# Release the automation server.
undef $qpst;

print "Done!\n";