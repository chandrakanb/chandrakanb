# Written for Perl 5.005_03, ActiveState Tool Corp. version 513.

use Win32::OLE;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

# Show (1) the $prod_id GUI or hide (0) it?
$show_gui = 0;

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

# Show the Automation server GUI. Off by default.
if ($show_gui)
{
  $qpst->ShowWindow();

  print "press enter to continue";
  <STDIN>;
}

# Translate phone mode to string.
%phone_mode_list = qw (
	0 modeNone
	1 modeDataServices
	2 modeDownload
	3 modeDiagnostic
	4 modeDiagnosticOffline
	5 modeReset
	6 modeStreamDownload) ;

# Translate phone status to string.
%phone_status_list = qw (
  0 phoneStatusNone
  1 phoneStatusInitializationInProgress
  2 phoneStatusPortNotPresent
  3 phoneStatusPhoneNotPresent
  4 phoneStatusPhoneNotSupported
  5 phoneStatusReady) ;

if (defined $qpst)
{
  # Find port selected on Automation server GUI.
  $port_selected = $qpst->GetSelectedPort();

  if (defined $port_selected)
  {
    $port_selected_name = $port_selected->PortName;

    print "port $port_selected_name selected\n" ;
  }
  else
  {
    # Either GUI hidden or port disabled.
    print "no port selected on GUI (or GUI hidden)\n";
  }

  undef $port_selected;

  # Get an object that contains a snapshot of enabled ports.
  $port_list = $qpst->GetPortList();

  if (defined $port_list)
  {
    # Iterate through all enabled ports.
    $phone_count = $port_list->PhoneCount;

    for ($i = 0 ; $i < $phone_count ; ++$i)
    {
      $port_name = $port_list->PortName($i);
      $port_label = $port_list->PortLabel($i);
      $is_usb = $port_list->IsUSB($i);
      $port_id = $port_list->PortId($i);
      $mode = $phone_mode_list{$port_list->PhoneMode($i)};
      $status = $phone_status_list{$port_list->PhoneStatus($i)};
      $hex_esn = sprintf("0x%08X", $port_list->ESN($i));
  
      # Display the state of each port.
      print "$port_id $port_name $is_usb $hex_esn \042$port_label\042 $mode $status\n";

      # For all ports that have a running phone get the port object.
      if ($mode eq "modeDiagnostic" || $mode eq "modeDiagnosticOffline")
      {
        $qpst_port = $qpst->GetPort($port_id);

        if (defined $qpst_port)
        {
          print "qpst_port available\n" ;

          # Get live data from the port object.
          $port_name_2 = $qpst_port->PortName;
          $port_label_2 = $qpst_port->PortLabel;
          $is_usb_2 = $qpst_port->IsUSB;
          $port_id_2 = $qpst_port->PortId;
          $mode_2 = $phone_mode_list{$qpst_port->PhoneMode};
          $status_2 = $phone_status_list{$qpst_port->PhoneStatus};
          $hex_esn_2 = sprintf("0x%08X", $qpst_port->ESN);

          # Display the state of the port.
          print "$port_id_2 $port_name_2 $is_usb_2 $hex_esn_2 \042$port_label_2\042 $mode_2 $status_2\n";
        }
        else
        {
          print "qpst_port not defined\n" ;
        }

        undef $qpst_port;
      }
    }

    # Release the port list component.
    undef $port_list;
  }
  else
  {
    print "NO port list returned\n";
  }
}

if ($show_gui)
{
  print "press enter to exit";
  <STDIN>;
}

# Release the automation server.
undef $qpst;

print "Done!\n";