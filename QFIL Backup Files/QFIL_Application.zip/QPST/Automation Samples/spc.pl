use Win32::OLE;

###############################################################################

# AppId for the Automation server.
$prod_id = "QPSTAtmnServer.Application";

# Show (1) the $prod_id GUI or hide (0) it?
$show_gui = 0;

###############################################################################

# Attempt to use a running instance.
eval
{
  $qpst = Win32::OLE->GetActiveObject($prod_id)
};

die "$prod_id not installed" if $@;

# Start a new instance. Call Quit when $qpst set to undef or script exits.
unless (defined $qpst)
{
  $qpst = Win32::OLE->new($prod_id, sub {$_[0]->Quit;}) or die "Oops, cannot start $prod_id";
}

# Show the Automation server GUI. Off by default.
if ($show_gui)
{
  $qpst->ShowWindow();

  print "press enter to continue";
  <STDIN>;
}

if (defined $qpst)
{
  # Find port selected on Automation server GUI.
  $port_selected = $qpst->GetSelectedPort();

  if (defined $port_selected)
  {
    $port_selected_name = $port_selected->PortName;

    print "Send SPC to $port_selected_name ? " ;

    $reply = <STDIN>;
    chomp($reply);

    if ($reply eq "y")
    {
      print "Enter SPC: ";

      $spc = <STDIN>;
      chomp($spc);

      if (length($spc) == 6)
      {
        $port_selected->SendSPC($spc);

        $last_error = Win32::OLE->LastError();

        if ($last_error != 0)
        {
          $status = sprintf("0x%08X", $last_error) ;

          print "Failed to unlock phone, error <$status>\n";
        }
      }
      else
      {
        print "SPC must be 6 characters!\n";
      }
    }
  }
  else
  {
    # Either GUI hidden or port disabled.
    print "no port selected\n";
  }

  undef $port_selected;
}

if ($show_gui)
{
  print "press enter to exit";
  <STDIN>;
}

# Release the automation server.
undef $qpst;

print "Done!\n";